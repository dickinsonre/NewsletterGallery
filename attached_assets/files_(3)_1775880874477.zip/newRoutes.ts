/**
 * ADDITIONAL ROUTES — paste these into routes.ts
 * 
 * New endpoints for:
 *   - GET /api/selection-sets         → Named selection groups
 *   - GET /api/scenarios/diff/:a/:b   → Compare two scenarios within same model
 *   - GET /api/merged-view/:type      → Merged attribute browser (DB Editor style)
 *   - PUT /api/element-data/:id       → Edit element properties
 */

import type { Express, Request, Response } from "express";
import { ScenarioBuilder } from "./scenarioBuilder";

// Add these after your existing route registrations in registerRoutes()
// Make sure /api/scenarios/diff/:a/:b comes BEFORE /api/scenarios/:id

export function registerNewRoutes(
  app: Express,
  currentFiles: Record<string, any>,
  currentModel: any,
  currentFolderType: "IEDB" | "ISDB" | "UNKNOWN"
) {

  // ── Selection Sets ──────────────────────────────────────────────────
  app.get("/api/selection-sets", (_req: Request, res: Response) => {
    if (!currentFiles || !Object.keys(currentFiles).length) {
      return res.json({ selections: {} });
    }
    const builder = new ScenarioBuilder(currentFiles, currentFolderType);
    const selections = builder.getSelectionSets();
    res.json({ selections });
  });

  // ── Scenario Comparison (within same model) ─────────────────────────
  // IMPORTANT: This route MUST come before /api/scenarios/:id
  app.get("/api/scenarios/diff/:a/:b", (req: Request, res: Response) => {
    const { a, b } = req.params;
    if (!currentFiles || !Object.keys(currentFiles).length) {
      return res.status(400).json({ error: "No model loaded" });
    }
    const builder = new ScenarioBuilder(currentFiles, currentFolderType);
    try {
      const diff = builder.compareScenarios(a, b);
      res.json(diff);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── Merged Attribute View (DB Editor style) ─────────────────────────
  // Returns all elements of a type with merged attributes from multiple tables
  app.get("/api/merged-view/:type", (req: Request, res: Response) => {
    const { type } = req.params;
    if (!currentFiles || !Object.keys(currentFiles).length) {
      return res.status(400).json({ error: "No model loaded" });
    }

    try {
      const merged = buildMergedView(currentFiles, currentFolderType, type);
      res.json(merged);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── Edit Element Properties ─────────────────────────────────────────
  // Updates a field in the in-memory model (persists until server restart)
  app.put("/api/element-data/:id", (req: Request, res: Response) => {
    const { id } = req.params;
    const { table, field, value } = req.body;

    if (!currentFiles || !table || !field) {
      return res.status(400).json({ error: "Missing table, field, or no model loaded" });
    }

    // Find the table in currentFiles
    let found = false;
    for (const key of Object.keys(currentFiles)) {
      const tableName = key.replace(/\.dbf$/i, "").split("/").pop()?.toUpperCase();
      if (tableName === table.toUpperCase()) {
        const records = currentFiles[key]?.records;
        if (records) {
          for (const rec of records) {
            const recId = String(rec.ID ?? rec.id ?? "").trim();
            if (recId === id) {
              rec[field] = value;
              found = true;
              break;
            }
          }
        }
        if (found) break;
      }
    }

    if (!found) {
      return res.status(404).json({ error: `Element ${id} not found in ${table}` });
    }

    res.json({ success: true, id, table, field, value });
  });
}

// ── Merged view builder ───────────────────────────────────────────────

interface MergedRecord {
  ID: string;
  _sources: string[];   // which DBF tables contributed
  [key: string]: any;
}

function getField(record: any, field: string): string {
  return String(
    record[field] ?? record[field.toUpperCase()] ?? record[field.toLowerCase()] ?? ""
  ).trim();
}

function getRecords(files: Record<string, any>, name: string): any[] {
  const upper = name.toUpperCase();
  for (const key of Object.keys(files)) {
    const keyName = key.replace(/\.dbf$/i, "").split("/").pop()?.toUpperCase();
    if (keyName === upper) {
      return files[key]?.records || [];
    }
  }
  return [];
}

function buildMergedView(
  files: Record<string, any>,
  folderType: "IEDB" | "ISDB" | "UNKNOWN",
  elementType: string
): { type: string; fields: string[]; records: MergedRecord[] } {

  // Define which tables to merge for each element type
  const mergeRules: Record<string, { tables: string[]; idField: string }> = {
    // ISDB (InfoSWMM) element types
    junctions: { tables: ["JUNCTION", "JCTHYD", "NODE"], idField: "ID" },
    conduits: { tables: ["CONDUIT", "CONHYD", "XSECTION", "LINK"], idField: "ID" },
    outfalls: { tables: ["OUTFALL", "OFALLHYD", "NODE"], idField: "ID" },
    storage: { tables: ["STORAGE", "STORHYD", "NODE"], idField: "ID" },
    pumps: { tables: ["PUMP", "PUMPHYD", "LINK"], idField: "ID" },
    orifices: { tables: ["ORIFICE", "ORIHYD", "LINK"], idField: "ID" },
    weirs: { tables: ["WEIR", "WEIRHYD", "LINK"], idField: "ID" },
    outlets: { tables: ["OUTLET", "OUTLHYD", "LINK"], idField: "ID" },
    subcatchments: { tables: ["SUBCATCH", "SUBAREA", "INFIL"], idField: "ID" },
    dividers: { tables: ["DIVIDER", "NODE"], idField: "ID" },

    // IEDB (InfoSewer) element types
    manholes: { tables: ["MANHOLE", "MHHYD", "NODE"], idField: "ID" },
    pipes: { tables: ["PIPE", "PIPEHYD", "LINK"], idField: "ID" },
    wetwells: { tables: ["WWELL", "WWELLHYD", "NODE"], idField: "ID" },
  };

  const rule = mergeRules[elementType.toLowerCase()];
  if (!rule) {
    return { type: elementType, fields: [], records: [] };
  }

  // Gather all records from each table, indexed by ID
  const mergedMap = new Map<string, MergedRecord>();

  for (const tableName of rule.tables) {
    const records = getRecords(files, tableName);
    for (const rec of records) {
      const id = getField(rec, rule.idField);
      if (!id) continue;

      if (!mergedMap.has(id)) {
        mergedMap.set(id, { ID: id, _sources: [] });
      }

      const merged = mergedMap.get(id)!;
      merged._sources.push(tableName);

      // Copy all fields (don't overwrite existing non-empty values)
      for (const [key, val] of Object.entries(rec)) {
        if (key.toUpperCase() === "ID") continue; // already set
        const existing = merged[key];
        if (existing === undefined || existing === "" || existing === null) {
          merged[key] = val;
        }
      }
    }
  }

  // Collect all field names
  const fieldSet = new Set<string>(["ID"]);
  for (const rec of mergedMap.values()) {
    for (const key of Object.keys(rec)) {
      if (key !== "_sources") fieldSet.add(key);
    }
  }

  return {
    type: elementType,
    fields: Array.from(fieldSet),
    records: Array.from(mergedMap.values()),
  };
}
