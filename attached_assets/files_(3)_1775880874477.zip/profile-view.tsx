/**
 * profile-view.tsx — Longitudinal Profile View
 *
 * InfoSWMM's most-used feature: click a path of connected conduits
 * and see invert elevations, ground/rim elevations, pipe sizes, and slopes.
 *
 * Usage: Add as a new tab or sub-panel of the Network tab.
 */

import { useState, useMemo, useCallback } from "react";
import { RotateCcw, Download, ArrowRight, Plus, Trash2 } from "lucide-react";

// ── Types (import from your shared schema) ────────────────────────────

interface NetworkNode {
  id: string;
  x: number;
  y: number;
  type: string;
  elevation?: number;
  depth?: number;
  maxDepth?: number;
  rimElev?: number;
  invElev?: number;
}

interface NetworkLink {
  id: string;
  from: string;
  to: string;
  type: string;
  diameter?: number;
  geom1?: number;
  length?: number;
  manning?: number;
  roughness?: number;
  slope?: number;
  upOffset?: number;
  dnOffset?: number;
  fromInv?: number;
  toInv?: number;
}

interface NetworkModel {
  nodes: NetworkNode[];
  links: NetworkLink[];
  bounds: any;
}

interface Props {
  model: NetworkModel;
  selectedElementId?: string | null;
}

// ── Profile data structure ────────────────────────────────────────────

interface ProfileStation {
  station: number;         // cumulative distance from start
  nodeId: string;
  groundElev: number;      // rim or surface elevation
  invertElev: number;      // pipe invert at this node
  depth: number;           // max depth at this node
  linkIdBefore?: string;   // link arriving at this node
  linkIdAfter?: string;    // link departing this node
  diameterBefore?: number;
  diameterAfter?: number;
}

// ── Component ─────────────────────────────────────────────────────────

export default function ProfileView({ model, selectedElementId }: Props) {
  const [pathNodeIds, setPathNodeIds] = useState<string[]>([]);
  const [autoTrace, setAutoTrace] = useState(true);

  // Build lookups
  const nodeMap = useMemo(() => {
    const m = new Map<string, NetworkNode>();
    for (const n of model.nodes) m.set(n.id, n);
    return m;
  }, [model.nodes]);

  const linksByFrom = useMemo(() => {
    const m = new Map<string, NetworkLink[]>();
    for (const l of model.links) {
      if (!m.has(l.from)) m.set(l.from, []);
      m.get(l.from)!.push(l);
    }
    return m;
  }, [model.links]);

  const linksByTo = useMemo(() => {
    const m = new Map<string, NetworkLink[]>();
    for (const l of model.links) {
      if (!m.has(l.to)) m.set(l.to, []);
      m.get(l.to)!.push(l);
    }
    return m;
  }, [model.links]);

  // Find link between two nodes
  const findLink = useCallback((fromId: string, toId: string): NetworkLink | undefined => {
    return model.links.find(l =>
      (l.from === fromId && l.to === toId) ||
      (l.from === toId && l.to === fromId)
    );
  }, [model.links]);

  // Auto-trace downstream from a starting node
  const traceDownstream = useCallback((startId: string, maxSteps = 50): string[] => {
    const path = [startId];
    const visited = new Set([startId]);
    let current = startId;

    for (let i = 0; i < maxSteps; i++) {
      const outLinks = linksByFrom.get(current) || [];
      // Pick first unvisited downstream node
      let next: string | null = null;
      for (const link of outLinks) {
        if (!visited.has(link.to)) {
          next = link.to;
          break;
        }
      }
      if (!next) break;
      visited.add(next);
      path.push(next);
      current = next;
    }

    return path;
  }, [linksByFrom]);

  // Auto-trace when element is selected on network canvas
  useMemo(() => {
    if (selectedElementId && autoTrace) {
      const node = nodeMap.get(selectedElementId);
      if (node) {
        setPathNodeIds(traceDownstream(selectedElementId));
      } else {
        // Maybe it's a link — trace from its upstream node
        const link = model.links.find(l => l.id === selectedElementId);
        if (link) {
          setPathNodeIds(traceDownstream(link.from));
        }
      }
    }
  }, [selectedElementId, autoTrace]);

  // Build profile stations from path
  const stations = useMemo((): ProfileStation[] => {
    if (pathNodeIds.length < 2) return [];

    const result: ProfileStation[] = [];
    let cumulDist = 0;

    for (let i = 0; i < pathNodeIds.length; i++) {
      const nodeId = pathNodeIds[i];
      const node = nodeMap.get(nodeId);
      if (!node) continue;

      const linkBefore = i > 0 ? findLink(pathNodeIds[i - 1], nodeId) : undefined;
      const linkAfter = i < pathNodeIds.length - 1 ? findLink(nodeId, pathNodeIds[i + 1]) : undefined;

      if (linkBefore) {
        cumulDist += linkBefore.length || 0;
      }

      const groundElev = node.rimElev ?? node.elevation ?? 0;
      const invertElev = node.invElev ?? (node.elevation != null && node.depth != null
        ? node.elevation - node.depth
        : node.elevation ?? 0);

      result.push({
        station: cumulDist,
        nodeId,
        groundElev,
        invertElev,
        depth: node.maxDepth ?? node.depth ?? (groundElev - invertElev),
        linkIdBefore: linkBefore?.id,
        linkIdAfter: linkAfter?.id,
        diameterBefore: linkBefore?.diameter ?? linkBefore?.geom1,
        diameterAfter: linkAfter?.diameter ?? linkAfter?.geom1,
      });
    }

    return result;
  }, [pathNodeIds, nodeMap, findLink]);

  // ── SVG rendering ──────────────────────────────────────────────────

  const svgWidth = 800;
  const svgHeight = 350;
  const margin = { top: 30, right: 40, bottom: 50, left: 70 };
  const plotW = svgWidth - margin.left - margin.right;
  const plotH = svgHeight - margin.top - margin.bottom;

  const { xScale, yScale, yMin, yMax, xMax } = useMemo(() => {
    if (stations.length < 2) return { xScale: () => 0, yScale: () => 0, yMin: 0, yMax: 1, xMax: 1 };

    const xs = stations.map(s => s.station);
    const ys = stations.flatMap(s => [s.groundElev, s.invertElev]);
    const xMin = Math.min(...xs);
    const xMax = Math.max(...xs);
    const yMin = Math.min(...ys) - 2;
    const yMax = Math.max(...ys) + 2;

    const xRange = xMax - xMin || 1;
    const yRange = yMax - yMin || 1;

    return {
      xScale: (v: number) => margin.left + ((v - xMin) / xRange) * plotW,
      yScale: (v: number) => margin.top + plotH - ((v - yMin) / yRange) * plotH,
      yMin, yMax, xMax: xMax || 1,
    };
  }, [stations]);

  // Export profile as CSV
  const exportCSV = useCallback(() => {
    if (stations.length === 0) return;
    const header = "Station,NodeID,GroundElev,InvertElev,Depth,PipeDiameter";
    const rows = stations.map(s =>
      `${s.station.toFixed(2)},${s.nodeId},${s.groundElev.toFixed(2)},${s.invertElev.toFixed(2)},${s.depth.toFixed(2)},${s.diameterAfter?.toFixed(2) ?? ""}`
    );
    const csv = [header, ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "profile.csv"; a.click();
  }, [stations]);

  return (
    <div className="h-full flex flex-col bg-gray-50 dark:bg-gray-900">
      {/* Toolbar */}
      <div className="flex items-center gap-2 px-4 py-2 border-b bg-white dark:bg-gray-800
        dark:border-gray-700 text-sm">
        <span className="font-semibold text-gray-700 dark:text-gray-200">
          Profile View
        </span>
        <span className="text-gray-400">|</span>
        <label className="flex items-center gap-1.5 text-xs text-gray-600 dark:text-gray-400">
          <input type="checkbox" checked={autoTrace} onChange={e => setAutoTrace(e.target.checked)}
            className="w-3 h-3 accent-blue-500" />
          Auto-trace downstream
        </label>
        <span className="text-gray-400">|</span>
        <span className="text-xs text-gray-500 dark:text-gray-400">
          {pathNodeIds.length} nodes, {pathNodeIds.length > 1 ? pathNodeIds.length - 1 : 0} links
        </span>
        <div className="flex-1" />
        <button onClick={() => setPathNodeIds([])}
          className="text-xs text-gray-500 hover:text-red-500 flex items-center gap-1">
          <RotateCcw size={12} /> Clear
        </button>
        <button onClick={exportCSV} disabled={stations.length === 0}
          className="text-xs text-gray-500 hover:text-blue-500 flex items-center gap-1
            disabled:opacity-30">
          <Download size={12} /> CSV
        </button>
      </div>

      {/* Profile chart */}
      {stations.length >= 2 ? (
        <div className="flex-1 overflow-auto p-4">
          <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full max-w-4xl mx-auto">
            {/* Grid lines */}
            {Array.from({ length: 6 }, (_, i) => {
              const v = yMin + ((yMax - yMin) * i) / 5;
              const y = yScale(v);
              return (
                <g key={`grid-${i}`}>
                  <line x1={margin.left} x2={svgWidth - margin.right}
                    y1={y} y2={y} stroke="#e5e7eb" strokeWidth={0.5} />
                  <text x={margin.left - 8} y={y + 3} textAnchor="end"
                    fontSize={9} fill="#6b7280">{v.toFixed(1)}</text>
                </g>
              );
            })}

            {/* Ground surface line */}
            <polyline
              points={stations.map(s => `${xScale(s.station)},${yScale(s.groundElev)}`).join(" ")}
              fill="none" stroke="#854d0e" strokeWidth={1.5} strokeDasharray="4 2"
            />

            {/* Pipe crown (invert + diameter) */}
            {stations.map((s, i) => {
              if (i >= stations.length - 1) return null;
              const next = stations[i + 1];
              const diam = s.diameterAfter || 1;
              const x1 = xScale(s.station), x2 = xScale(next.station);
              const y1 = yScale(s.invertElev + diam);
              const y2 = yScale(next.invertElev + diam);
              return (
                <line key={`crown-${i}`}
                  x1={x1} y1={y1} x2={x2} y2={y2}
                  stroke="#93c5fd" strokeWidth={1} strokeDasharray="3 2" />
              );
            })}

            {/* Pipe invert line (main profile) */}
            <polyline
              points={stations.map(s => `${xScale(s.station)},${yScale(s.invertElev)}`).join(" ")}
              fill="none" stroke="#2563eb" strokeWidth={2}
            />

            {/* Pipe fills (shaded area between invert and crown) */}
            {stations.map((s, i) => {
              if (i >= stations.length - 1) return null;
              const next = stations[i + 1];
              const diam = s.diameterAfter || 0;
              if (diam <= 0) return null;
              const x1 = xScale(s.station), x2 = xScale(next.station);
              return (
                <polygon key={`pipe-${i}`}
                  points={`${x1},${yScale(s.invertElev)} ${x2},${yScale(next.invertElev)} ${x2},${yScale(next.invertElev + diam)} ${x1},${yScale(s.invertElev + diam)}`}
                  fill="rgba(59,130,246,0.08)" stroke="none"
                />
              );
            })}

            {/* Node markers */}
            {stations.map((s, i) => {
              const x = xScale(s.station);
              return (
                <g key={`marker-${i}`}>
                  {/* Vertical line from ground to invert */}
                  <line x1={x} y1={yScale(s.groundElev)} x2={x} y2={yScale(s.invertElev)}
                    stroke="#9ca3af" strokeWidth={0.5} strokeDasharray="2 2" />
                  {/* Ground dot */}
                  <circle cx={x} cy={yScale(s.groundElev)} r={3}
                    fill="#854d0e" stroke="white" strokeWidth={0.5} />
                  {/* Invert dot */}
                  <circle cx={x} cy={yScale(s.invertElev)} r={3}
                    fill="#2563eb" stroke="white" strokeWidth={0.5} />
                  {/* Node ID label */}
                  <text x={x} y={svgHeight - margin.bottom + 15}
                    textAnchor="middle" fontSize={7} fill="#374151"
                    transform={`rotate(-45, ${x}, ${svgHeight - margin.bottom + 15})`}>
                    {s.nodeId}
                  </text>
                  {/* Diameter annotation */}
                  {s.diameterAfter && i < stations.length - 1 && (
                    <text
                      x={(x + xScale(stations[i + 1].station)) / 2}
                      y={yScale(s.invertElev) + 12}
                      textAnchor="middle" fontSize={7} fill="#2563eb" fontWeight="bold">
                      ⌀{s.diameterAfter.toFixed(1)}
                    </text>
                  )}
                </g>
              );
            })}

            {/* Axis labels */}
            <text x={svgWidth / 2} y={svgHeight - 5} textAnchor="middle"
              fontSize={10} fill="#374151">Station (ft)</text>
            <text x={12} y={svgHeight / 2} textAnchor="middle"
              fontSize={10} fill="#374151"
              transform={`rotate(-90, 12, ${svgHeight / 2})`}>Elevation (ft)</text>

            {/* Legend */}
            <g transform={`translate(${margin.left + 10}, ${margin.top + 5})`}>
              <line x1={0} y1={0} x2={20} y2={0} stroke="#854d0e" strokeWidth={1.5} strokeDasharray="4 2" />
              <text x={24} y={3} fontSize={8} fill="#854d0e">Ground / Rim</text>
              <line x1={0} y1={14} x2={20} y2={14} stroke="#2563eb" strokeWidth={2} />
              <text x={24} y={17} fontSize={8} fill="#2563eb">Pipe Invert</text>
              <line x1={0} y1={28} x2={20} y2={28} stroke="#93c5fd" strokeWidth={1} strokeDasharray="3 2" />
              <text x={24} y={31} fontSize={8} fill="#93c5fd">Pipe Crown</text>
            </g>
          </svg>

          {/* Profile data table */}
          <div className="mt-4 overflow-x-auto">
            <table className="text-xs border-collapse w-full max-w-4xl mx-auto">
              <thead>
                <tr className="bg-gray-100 dark:bg-gray-800">
                  <th className="px-3 py-1.5 text-left font-semibold">Node</th>
                  <th className="px-3 py-1.5 text-right font-semibold">Station (ft)</th>
                  <th className="px-3 py-1.5 text-right font-semibold">Ground Elev</th>
                  <th className="px-3 py-1.5 text-right font-semibold">Invert Elev</th>
                  <th className="px-3 py-1.5 text-right font-semibold">Depth</th>
                  <th className="px-3 py-1.5 text-right font-semibold">Pipe Diam</th>
                  <th className="px-3 py-1.5 text-left font-semibold">Link</th>
                </tr>
              </thead>
              <tbody>
                {stations.map((s, i) => (
                  <tr key={i} className="border-t border-gray-200 dark:border-gray-700
                    hover:bg-blue-50 dark:hover:bg-blue-900/20">
                    <td className="px-3 py-1 font-mono">{s.nodeId}</td>
                    <td className="px-3 py-1 text-right">{s.station.toFixed(1)}</td>
                    <td className="px-3 py-1 text-right">{s.groundElev.toFixed(2)}</td>
                    <td className="px-3 py-1 text-right">{s.invertElev.toFixed(2)}</td>
                    <td className="px-3 py-1 text-right">{s.depth.toFixed(2)}</td>
                    <td className="px-3 py-1 text-right">{s.diameterAfter?.toFixed(2) ?? "—"}</td>
                    <td className="px-3 py-1 font-mono text-gray-500">{s.linkIdAfter ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center text-gray-400 text-sm">
          <div className="text-center space-y-2">
            <ArrowRight size={32} className="mx-auto opacity-50" />
            <p>Select a node on the network map to trace a profile</p>
            <p className="text-xs">or click nodes sequentially to build a custom path</p>
          </div>
        </div>
      )}
    </div>
  );
}
