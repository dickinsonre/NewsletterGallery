/**
 * property-panel-editable.tsx — DROP-IN REPLACEMENT for property-panel.tsx
 *
 * Changes from original:
 *   - Fields are editable (click to edit, Enter to save, Escape to cancel)
 *   - Saves edits to server via PUT /api/element-data/:id
 *   - Visual feedback for modified fields (blue highlight)
 *   - "Modified" badge on changed properties
 *   - Undo last edit
 */

import { useState, useEffect, useCallback, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Edit3, Save, X, Undo2, ChevronDown, ChevronRight } from "lucide-react";

interface Props {
  elementId: string | null;
  elementType: "node" | "link" | "subcatchment";
}

interface TableGroup {
  tableName: string;
  matchField: string;
  fields: { name: string; value: any; original?: any; modified?: boolean }[];
}

export default function PropertyPanelEditable({ elementId, elementType }: Props) {
  const queryClient = useQueryClient();
  const [editingCell, setEditingCell] = useState<{ table: string; field: string } | null>(null);
  const [editValue, setEditValue] = useState("");
  const [modifications, setModifications] = useState<Record<string, Record<string, { newValue: any; oldValue: any }>>>({});
  const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(new Set());
  const inputRef = useRef<HTMLInputElement>(null);

  // Fetch element data
  const { data, isLoading } = useQuery({
    queryKey: ["element-data", elementId],
    queryFn: async () => {
      if (!elementId) return null;
      const res = await fetch(`/api/element-data/${encodeURIComponent(elementId)}`);
      if (!res.ok) throw new Error("Failed to load element data");
      return res.json();
    },
    enabled: !!elementId,
  });

  // Save mutation
  const saveMutation = useMutation({
    mutationFn: async (params: { id: string; table: string; field: string; value: any }) => {
      const res = await fetch(`/api/element-data/${encodeURIComponent(params.id)}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          table: params.table,
          field: params.field,
          value: params.value,
        }),
      });
      if (!res.ok) throw new Error("Save failed");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["element-data", elementId] });
    },
  });

  // Reset modifications when element changes
  useEffect(() => {
    setModifications({});
    setEditingCell(null);
  }, [elementId]);

  // Focus input when editing starts
  useEffect(() => {
    if (editingCell && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editingCell]);

  const startEdit = useCallback((table: string, field: string, currentValue: any) => {
    setEditingCell({ table, field });
    setEditValue(String(currentValue ?? ""));
  }, []);

  const cancelEdit = useCallback(() => {
    setEditingCell(null);
    setEditValue("");
  }, []);

  const saveEdit = useCallback(() => {
    if (!editingCell || !elementId) return;
    const { table, field } = editingCell;

    // Track modification
    const originalValue = data?.tables
      ?.find((t: any) => t.tableName === table)
      ?.fields?.find((f: any) => f.name === field)?.value;

    setModifications(prev => ({
      ...prev,
      [table]: {
        ...prev[table],
        [field]: { newValue: editValue, oldValue: originalValue },
      },
    }));

    // Save to server
    saveMutation.mutate({ id: elementId, table, field, value: editValue });
    setEditingCell(null);
  }, [editingCell, editValue, elementId, data, saveMutation]);

  const undoEdit = useCallback((table: string, field: string) => {
    if (!elementId) return;
    const mod = modifications[table]?.[field];
    if (!mod) return;

    saveMutation.mutate({ id: elementId, table, field, value: mod.oldValue });

    setModifications(prev => {
      const next = { ...prev };
      if (next[table]) {
        delete next[table][field];
        if (Object.keys(next[table]).length === 0) delete next[table];
      }
      return next;
    });
  }, [elementId, modifications, saveMutation]);

  const toggleGroup = useCallback((name: string) => {
    setCollapsedGroups(prev => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name); else next.add(name);
      return next;
    });
  }, []);

  // Count total modifications
  const modCount = Object.values(modifications).reduce(
    (acc, fields) => acc + Object.keys(fields).length, 0
  );

  if (!elementId) {
    return (
      <div className="p-4 text-center text-gray-400 text-sm">
        <Edit3 size={24} className="mx-auto mb-2 opacity-50" />
        <p>Select an element to view and edit properties</p>
      </div>
    );
  }

  if (isLoading) {
    return <div className="p-4 text-sm text-gray-500">Loading properties...</div>;
  }

  const tables: TableGroup[] = data?.tables || [];

  return (
    <div className="h-full overflow-y-auto text-sm">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white dark:bg-gray-900 border-b
        dark:border-gray-700 px-3 py-2">
        <div className="flex items-center justify-between">
          <div>
            <span className="font-semibold text-gray-800 dark:text-gray-100">{elementId}</span>
            <span className="ml-2 text-xs text-gray-400">{elementType}</span>
          </div>
          {modCount > 0 && (
            <span className="text-xs bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300
              px-2 py-0.5 rounded-full">
              {modCount} modified
            </span>
          )}
        </div>
      </div>

      {/* Property groups */}
      {tables.map((group: TableGroup) => {
        const isCollapsed = collapsedGroups.has(group.tableName);
        const groupMods = modifications[group.tableName] || {};
        const hasGroupMods = Object.keys(groupMods).length > 0;

        return (
          <div key={group.tableName} className="border-b dark:border-gray-800">
            {/* Group header */}
            <button
              className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold
                text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 uppercase tracking-wide"
              onClick={() => toggleGroup(group.tableName)}
            >
              {isCollapsed ? <ChevronRight size={12} /> : <ChevronDown size={12} />}
              <span className="flex-1 text-left">{group.tableName}</span>
              {group.matchField && (
                <span className="text-gray-400 font-normal normal-case">
                  matched by {group.matchField}
                </span>
              )}
              {hasGroupMods && (
                <span className="w-2 h-2 bg-blue-500 rounded-full" />
              )}
            </button>

            {/* Fields */}
            {!isCollapsed && (
              <div className="divide-y divide-gray-50 dark:divide-gray-800">
                {group.fields?.map((field: any) => {
                  const isEditing = editingCell?.table === group.tableName &&
                    editingCell?.field === field.name;
                  const mod = groupMods[field.name];
                  const isModified = !!mod;
                  const displayValue = isModified ? mod.newValue : field.value;

                  return (
                    <div
                      key={field.name}
                      className={`flex items-center px-3 py-1.5 gap-2 group ${
                        isModified ? "bg-blue-50/50 dark:bg-blue-950/30" : ""
                      }`}
                    >
                      {/* Field name */}
                      <span className="w-32 shrink-0 text-xs text-gray-500 dark:text-gray-400 truncate"
                        title={field.name}>
                        {field.name}
                      </span>

                      {/* Value / editor */}
                      {isEditing ? (
                        <div className="flex-1 flex items-center gap-1">
                          <input
                            ref={inputRef}
                            className="flex-1 bg-white dark:bg-gray-800 border border-blue-400
                              rounded px-2 py-0.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                            value={editValue}
                            onChange={e => setEditValue(e.target.value)}
                            onKeyDown={e => {
                              if (e.key === "Enter") saveEdit();
                              if (e.key === "Escape") cancelEdit();
                            }}
                          />
                          <button onClick={saveEdit}
                            className="p-0.5 text-green-500 hover:text-green-700">
                            <Save size={12} />
                          </button>
                          <button onClick={cancelEdit}
                            className="p-0.5 text-gray-400 hover:text-red-500">
                            <X size={12} />
                          </button>
                        </div>
                      ) : (
                        <div
                          className="flex-1 text-xs text-gray-800 dark:text-gray-200 font-mono truncate
                            cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800 px-2 py-0.5 rounded
                            group-hover:ring-1 group-hover:ring-gray-200 dark:group-hover:ring-gray-700"
                          onClick={() => startEdit(group.tableName, field.name, displayValue)}
                          title="Click to edit"
                        >
                          {displayValue ?? <span className="text-gray-300 italic">null</span>}
                        </div>
                      )}

                      {/* Modified indicator + undo */}
                      {isModified && !isEditing && (
                        <button
                          className="p-0.5 text-blue-400 hover:text-blue-600"
                          onClick={() => undoEdit(group.tableName, field.name)}
                          title="Undo change"
                        >
                          <Undo2 size={12} />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
