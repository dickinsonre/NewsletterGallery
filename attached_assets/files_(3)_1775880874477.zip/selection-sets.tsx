/**
 * selection-sets.tsx — Named Selection Groups Browser
 *
 * Reads Select/{name}/ANODE.dbf and ALINK.dbf from the model
 * and lets users browse, highlight, and export named selections.
 * Mirrors InfoSWMM's named selection functionality.
 */

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CheckSquare, Eye, Download, Filter } from "lucide-react";

interface SelectionSet {
  nodes: string[];
  links: string[];
}

interface Props {
  onHighlightElements?: (ids: string[]) => void;
  onFilterToSelection?: (ids: string[]) => void;
}

export default function SelectionSets({ onHighlightElements, onFilterToSelection }: Props) {
  const [activeSelection, setActiveSelection] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["selection-sets"],
    queryFn: async () => {
      const res = await fetch("/api/selection-sets");
      if (!res.ok) throw new Error("Failed to load selection sets");
      return res.json() as Promise<{ selections: Record<string, SelectionSet> }>;
    },
  });

  const selections = data?.selections || {};
  const selNames = Object.keys(selections).sort();

  const activeSet = activeSelection ? selections[activeSelection] : null;
  const allIds = activeSet ? [...activeSet.nodes, ...activeSet.links] : [];

  const handleActivate = (name: string) => {
    setActiveSelection(prev => prev === name ? null : name);
    const set = selections[name];
    if (set) {
      onHighlightElements?.([...set.nodes, ...set.links]);
    }
  };

  const exportSelection = (name: string) => {
    const set = selections[name];
    if (!set) return;
    const lines = [
      `Selection: ${name}`,
      `Nodes (${set.nodes.length}):`,
      ...set.nodes.map(id => `  ${id}`),
      `Links (${set.links.length}):`,
      ...set.links.map(id => `  ${id}`),
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `selection_${name}.txt`; a.click();
  };

  if (isLoading) {
    return <div className="p-4 text-sm text-gray-500">Loading selection sets...</div>;
  }

  if (selNames.length === 0) {
    return (
      <div className="p-6 text-center text-gray-400 text-sm">
        <CheckSquare size={32} className="mx-auto mb-2 opacity-50" />
        <p>No named selections found</p>
        <p className="text-xs mt-1">
          Selection sets are stored in Select/&#123;name&#125;/ANODE.dbf and ALINK.dbf
        </p>
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-3 border-b bg-gray-50 dark:bg-gray-800 dark:border-gray-700">
        <h3 className="font-semibold text-sm text-gray-700 dark:text-gray-200">
          Named Selections ({selNames.length})
        </h3>
        <p className="text-xs text-gray-500 mt-0.5">
          Click to highlight elements on the network map
        </p>
      </div>

      <div className="divide-y divide-gray-100 dark:divide-gray-800">
        {selNames.map(name => {
          const set = selections[name];
          const isActive = activeSelection === name;
          return (
            <div
              key={name}
              className={`px-4 py-3 cursor-pointer transition-colors ${
                isActive
                  ? "bg-blue-50 dark:bg-blue-900/30 border-l-2 border-blue-500"
                  : "hover:bg-gray-50 dark:hover:bg-gray-800 border-l-2 border-transparent"
              }`}
              onClick={() => handleActivate(name)}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-sm text-gray-800 dark:text-gray-100">
                    {name}
                  </div>
                  <div className="text-xs text-gray-500 mt-0.5">
                    {set.nodes.length} nodes · {set.links.length} links
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    className="p-1.5 rounded hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-400
                      hover:text-blue-500"
                    onClick={e => { e.stopPropagation(); onHighlightElements?.([...set.nodes, ...set.links]); }}
                    title="Highlight on map"
                  >
                    <Eye size={14} />
                  </button>
                  <button
                    className="p-1.5 rounded hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-400
                      hover:text-green-500"
                    onClick={e => { e.stopPropagation(); onFilterToSelection?.([...set.nodes, ...set.links]); }}
                    title="Filter to selection"
                  >
                    <Filter size={14} />
                  </button>
                  <button
                    className="p-1.5 rounded hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-400
                      hover:text-amber-500"
                    onClick={e => { e.stopPropagation(); exportSelection(name); }}
                    title="Export selection list"
                  >
                    <Download size={14} />
                  </button>
                </div>
              </div>

              {/* Show element IDs when active */}
              {isActive && (
                <div className="mt-2 text-xs space-y-1">
                  {set.nodes.length > 0 && (
                    <div>
                      <span className="text-blue-600 dark:text-blue-400 font-medium">Nodes: </span>
                      <span className="text-gray-500 font-mono">
                        {set.nodes.slice(0, 20).join(", ")}
                        {set.nodes.length > 20 && ` ... +${set.nodes.length - 20} more`}
                      </span>
                    </div>
                  )}
                  {set.links.length > 0 && (
                    <div>
                      <span className="text-green-600 dark:text-green-400 font-medium">Links: </span>
                      <span className="text-gray-500 font-mono">
                        {set.links.slice(0, 20).join(", ")}
                        {set.links.length > 20 && ` ... +${set.links.length - 20} more`}
                      </span>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
