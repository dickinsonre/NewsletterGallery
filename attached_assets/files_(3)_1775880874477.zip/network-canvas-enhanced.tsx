/**
 * network-canvas-enhanced.tsx — DROP-IN REPLACEMENT for network-canvas.tsx
 *
 * New features:
 *   - Color-coding links by attribute (diameter, Manning's n, length, slope, type)
 *   - Color-coding nodes by attribute (elevation, depth, type)
 *   - Layer visibility toggles (nodes, links, subcatchments, labels)
 *   - Label display (ID, elevation, diameter)
 *   - Color legend
 *   - Selection highlighting with multi-select (Ctrl+click)
 *   - InfoSWMM-style map controls panel
 */

import { useState, useRef, useEffect, useMemo, useCallback } from "react";
import { Eye, EyeOff, Layers, Palette, Tag, ZoomIn, ZoomOut, Maximize } from "lucide-react";

// ── Types ──────────────────────────────────────────────────────────────

interface NetworkNode {
  id: string;
  x: number;
  y: number;
  type: string;
  elevation?: number;
  depth?: number;
  maxDepth?: number;
  inactive?: boolean;
}

interface NetworkLink {
  id: string;
  from: string;
  to: string;
  type: string;
  diameter?: number;
  length?: number;
  roughness?: number;
  manning?: number;
  slope?: number;
  geom1?: number;
  shape?: string;
  vertices?: { x: number; y: number }[];
  inactive?: boolean;
}

interface SubcatchmentPolygon {
  id: string;
  area?: number;
  imperv?: number;
  points: { x: number; y: number }[];
}

interface NetworkModel {
  nodes: NetworkNode[];
  links: NetworkLink[];
  subcatchments?: SubcatchmentPolygon[];
  bounds: { minX: number; minY: number; maxX: number; maxY: number };
}

interface Props {
  model: NetworkModel;
  selectedElement?: string | null;
  onSelectElement?: (id: string, type: "node" | "link" | "subcatchment") => void;
  scenarioLabel?: string;
  activeScenario?: string;
}

// ── Color scales ──────────────────────────────────────────────────────

type ColorAttribute = "none" | "diameter" | "manning" | "length" | "slope" | "type" | "elevation" | "depth";

const COLOR_RAMPS = {
  blueRed: [
    "#313695", "#4575b4", "#74add1", "#abd9e9", "#e0f3f8",
    "#fee090", "#fdae61", "#f46d43", "#d73027", "#a50026",
  ],
  greenBrown: [
    "#1a9850", "#66bd63", "#a6d96a", "#d9ef8b", "#ffffbf",
    "#fee08b", "#fdae61", "#f46d43", "#d73027", "#a50026",
  ],
};

const TYPE_COLORS: Record<string, string> = {
  conduit: "#2563eb",
  pipe: "#2563eb",
  pump: "#dc2626",
  orifice: "#f59e0b",
  weir: "#8b5cf6",
  outlet: "#06b6d4",
  junction: "#3b82f6",
  manhole: "#3b82f6",
  outfall: "#ef4444",
  storage: "#10b981",
  wetwell: "#10b981",
  divider: "#f97316",
};

function interpolateColor(value: number, min: number, max: number, ramp: string[]): string {
  if (max === min) return ramp[Math.floor(ramp.length / 2)];
  const t = Math.max(0, Math.min(1, (value - min) / (max - min)));
  const idx = t * (ramp.length - 1);
  const lo = Math.floor(idx);
  const hi = Math.min(lo + 1, ramp.length - 1);
  // Simple: just pick nearest
  return idx - lo < 0.5 ? ramp[lo] : ramp[hi];
}

function getNumericRange(items: any[], field: string): { min: number; max: number } {
  let min = Infinity, max = -Infinity;
  for (const item of items) {
    const v = parseFloat(item[field]);
    if (!isNaN(v) && isFinite(v)) {
      if (v < min) min = v;
      if (v > max) max = v;
    }
  }
  if (!isFinite(min)) { min = 0; max = 1; }
  return { min, max };
}

// ── Main Component ────────────────────────────────────────────────────

export default function NetworkCanvasEnhanced({
  model,
  selectedElement,
  onSelectElement,
  scenarioLabel,
}: Props) {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // View state
  const [viewBox, setViewBox] = useState({ x: 0, y: 0, w: 100, h: 100 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0, vx: 0, vy: 0 });

  // Layer controls
  const [showNodes, setShowNodes] = useState(true);
  const [showLinks, setShowLinks] = useState(true);
  const [showSubcatchments, setShowSubcatchments] = useState(true);
  const [showInactive, setShowInactive] = useState(false);
  const [showLabels, setShowLabels] = useState(false);
  const [labelField, setLabelField] = useState<"id" | "elevation" | "diameter">("id");

  // Color coding
  const [linkColorBy, setLinkColorBy] = useState<ColorAttribute>("none");
  const [nodeColorBy, setNodeColorBy] = useState<ColorAttribute>("none");

  // UI panels
  const [showLayerPanel, setShowLayerPanel] = useState(false);
  const [showColorPanel, setShowColorPanel] = useState(false);

  // Multi-select
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Build node lookup
  const nodeMap = useMemo(() => {
    const map = new Map<string, NetworkNode>();
    for (const n of model.nodes) map.set(n.id, n);
    return map;
  }, [model.nodes]);

  // Fit to bounds on model change
  useEffect(() => {
    fitToBounds();
  }, [model]);

  // Sync external selection
  useEffect(() => {
    if (selectedElement) {
      setSelectedIds(new Set([selectedElement]));
    }
  }, [selectedElement]);

  const fitToBounds = useCallback(() => {
    const { minX, minY, maxX, maxY } = model.bounds;
    const w = maxX - minX || 100;
    const h = maxY - minY || 100;
    const pad = Math.max(w, h) * 0.05;
    setViewBox({
      x: minX - pad,
      y: minY - pad,
      w: w + pad * 2,
      h: h + pad * 2,
    });
  }, [model.bounds]);

  // ── Color computation ───────────────────────────────────────────────

  const linkColors = useMemo(() => {
    if (linkColorBy === "none") return null;
    if (linkColorBy === "type") {
      const map = new Map<string, string>();
      for (const link of model.links) {
        map.set(link.id, TYPE_COLORS[link.type?.toLowerCase()] || "#6b7280");
      }
      return { map, legend: Object.entries(TYPE_COLORS).filter(([k]) =>
        model.links.some(l => l.type?.toLowerCase() === k)
      )};
    }

    const fieldMap: Record<string, string> = {
      diameter: "diameter",
      manning: "manning",
      length: "length",
      slope: "slope",
    };
    const field = fieldMap[linkColorBy];
    if (!field) return null;

    const altField = linkColorBy === "diameter" ? "geom1" : linkColorBy === "manning" ? "roughness" : field;
    const range = getNumericRange(
      model.links.map(l => ({ v: (l as any)[field] ?? (l as any)[altField] })),
      "v"
    );

    const map = new Map<string, string>();
    for (const link of model.links) {
      const v = parseFloat((link as any)[field] ?? (link as any)[altField]);
      if (!isNaN(v)) {
        map.set(link.id, interpolateColor(v, range.min, range.max, COLOR_RAMPS.blueRed));
      } else {
        map.set(link.id, "#9ca3af");
      }
    }
    return { map, range, field: linkColorBy };
  }, [linkColorBy, model.links]);

  const nodeColors = useMemo(() => {
    if (nodeColorBy === "none") return null;
    if (nodeColorBy === "type") {
      const map = new Map<string, string>();
      for (const node of model.nodes) {
        map.set(node.id, TYPE_COLORS[node.type?.toLowerCase()] || "#6b7280");
      }
      return { map };
    }

    const field = nodeColorBy === "elevation" ? "elevation" : "depth";
    const altField = nodeColorBy === "depth" ? "maxDepth" : field;
    const range = getNumericRange(
      model.nodes.map(n => ({ v: (n as any)[field] ?? (n as any)[altField] })),
      "v"
    );

    const map = new Map<string, string>();
    for (const node of model.nodes) {
      const v = parseFloat((node as any)[field] ?? (node as any)[altField]);
      if (!isNaN(v)) {
        map.set(node.id, interpolateColor(v, range.min, range.max, COLOR_RAMPS.greenBrown));
      } else {
        map.set(node.id, "#9ca3af");
      }
    }
    return { map, range, field: nodeColorBy };
  }, [nodeColorBy, model.nodes]);

  // ── Mouse handlers ──────────────────────────────────────────────────

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const factor = e.deltaY > 0 ? 1.15 : 0.87;
    const svg = svgRef.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    const mx = (e.clientX - rect.left) / rect.width;
    const my = (e.clientY - rect.top) / rect.height;

    setViewBox(v => {
      const nw = v.w * factor;
      const nh = v.h * factor;
      return {
        x: v.x + (v.w - nw) * mx,
        y: v.y + (v.h - nh) * my,
        w: nw,
        h: nh,
      };
    });
  }, []);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button !== 0) return;
    setIsPanning(true);
    setPanStart({ x: e.clientX, y: e.clientY, vx: viewBox.x, vy: viewBox.y });
  }, [viewBox]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isPanning) return;
    const svg = svgRef.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    const dx = ((e.clientX - panStart.x) / rect.width) * viewBox.w;
    const dy = ((e.clientY - panStart.y) / rect.height) * viewBox.h;
    setViewBox(v => ({ ...v, x: panStart.vx - dx, y: panStart.vy - dy }));
  }, [isPanning, panStart, viewBox.w, viewBox.h]);

  const handleMouseUp = useCallback(() => setIsPanning(false), []);

  const handleElementClick = useCallback((e: React.MouseEvent, id: string, type: "node" | "link" | "subcatchment") => {
    e.stopPropagation();
    if (e.ctrlKey || e.metaKey) {
      setSelectedIds(prev => {
        const next = new Set(prev);
        if (next.has(id)) next.delete(id);
        else next.add(id);
        return next;
      });
    } else {
      setSelectedIds(new Set([id]));
    }
    onSelectElement?.(id, type);
  }, [onSelectElement]);

  // ── Coordinate transform (flip Y for screen) ───────────────────────

  const tx = useCallback((x: number) => x, []);
  const ty = useCallback((y: number) => {
    // Flip Y: SVG Y increases downward, map Y increases upward
    return viewBox.y + viewBox.h - (y - viewBox.y);
  }, [viewBox]);

  // ── Render ──────────────────────────────────────────────────────────

  const nodeRadius = Math.max(viewBox.w, viewBox.h) * 0.004;
  const strokeWidth = Math.max(viewBox.w, viewBox.h) * 0.002;
  const fontSize = Math.max(viewBox.w, viewBox.h) * 0.008;

  return (
    <div ref={containerRef} className="relative w-full h-full bg-gray-950 select-none">

      {/* ── Scenario banner ── */}
      {scenarioLabel && (
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-20
          bg-amber-500/90 text-black text-xs font-bold px-3 py-1 rounded-full">
          Scenario: {scenarioLabel}
        </div>
      )}

      {/* ── Toolbar ── */}
      <div className="absolute top-2 right-2 z-20 flex flex-col gap-1">
        <ToolBtn icon={<Layers size={16}/>} active={showLayerPanel}
          onClick={() => { setShowLayerPanel(v => !v); setShowColorPanel(false); }} title="Layers" />
        <ToolBtn icon={<Palette size={16}/>} active={showColorPanel}
          onClick={() => { setShowColorPanel(v => !v); setShowLayerPanel(false); }} title="Color By" />
        <ToolBtn icon={<Tag size={16}/>} active={showLabels}
          onClick={() => setShowLabels(v => !v)} title="Labels" />
        <div className="h-px bg-gray-700 my-0.5" />
        <ToolBtn icon={<ZoomIn size={16}/>}
          onClick={() => setViewBox(v => ({
            x: v.x + v.w * 0.1, y: v.y + v.h * 0.1,
            w: v.w * 0.8, h: v.h * 0.8
          }))} title="Zoom In" />
        <ToolBtn icon={<ZoomOut size={16}/>}
          onClick={() => setViewBox(v => ({
            x: v.x - v.w * 0.125, y: v.y - v.h * 0.125,
            w: v.w * 1.25, h: v.h * 1.25
          }))} title="Zoom Out" />
        <ToolBtn icon={<Maximize size={16}/>}
          onClick={fitToBounds} title="Fit" />
      </div>

      {/* ── Layer Panel ── */}
      {showLayerPanel && (
        <div className="absolute top-2 right-14 z-30 bg-gray-900/95 border border-gray-700
          rounded-lg p-3 w-52 text-xs text-gray-200 space-y-2 shadow-xl">
          <div className="font-semibold text-gray-100 mb-1">Layer Visibility</div>
          <LayerToggle label="Nodes" checked={showNodes} onChange={setShowNodes} count={model.nodes.length} />
          <LayerToggle label="Links" checked={showLinks} onChange={setShowLinks} count={model.links.length} />
          <LayerToggle label="Subcatchments" checked={showSubcatchments} onChange={setShowSubcatchments}
            count={model.subcatchments?.length || 0} />
          <LayerToggle label="Inactive Elements" checked={showInactive} onChange={setShowInactive} />
          <div className="border-t border-gray-700 pt-2 mt-2">
            <div className="font-semibold text-gray-100 mb-1">Labels</div>
            <LayerToggle label="Show Labels" checked={showLabels} onChange={setShowLabels} />
            {showLabels && (
              <select className="w-full mt-1 bg-gray-800 border border-gray-600 rounded px-2 py-1 text-xs"
                value={labelField} onChange={e => setLabelField(e.target.value as any)}>
                <option value="id">Element ID</option>
                <option value="elevation">Elevation</option>
                <option value="diameter">Diameter</option>
              </select>
            )}
          </div>
        </div>
      )}

      {/* ── Color Panel ── */}
      {showColorPanel && (
        <div className="absolute top-2 right-14 z-30 bg-gray-900/95 border border-gray-700
          rounded-lg p-3 w-56 text-xs text-gray-200 space-y-2 shadow-xl">
          <div className="font-semibold text-gray-100">Color Links By</div>
          <select className="w-full bg-gray-800 border border-gray-600 rounded px-2 py-1"
            value={linkColorBy} onChange={e => setLinkColorBy(e.target.value as ColorAttribute)}>
            <option value="none">Default (single color)</option>
            <option value="diameter">Diameter / Geom1</option>
            <option value="manning">Manning's n / Roughness</option>
            <option value="length">Length</option>
            <option value="slope">Slope</option>
            <option value="type">Element Type</option>
          </select>
          <div className="font-semibold text-gray-100 mt-2">Color Nodes By</div>
          <select className="w-full bg-gray-800 border border-gray-600 rounded px-2 py-1"
            value={nodeColorBy} onChange={e => setNodeColorBy(e.target.value as ColorAttribute)}>
            <option value="none">Default (by type)</option>
            <option value="elevation">Elevation</option>
            <option value="depth">Max Depth</option>
            <option value="type">Element Type</option>
          </select>
        </div>
      )}

      {/* ── Color Legend ── */}
      {(linkColors || nodeColors) && (
        <div className="absolute bottom-2 left-2 z-20 bg-gray-900/90 border border-gray-700
          rounded-lg p-2 text-xs text-gray-200 space-y-1">
          {linkColors && 'range' in linkColors && linkColors.range && (
            <div>
              <div className="font-semibold mb-1">Links: {linkColors.field}</div>
              <div className="flex items-center gap-1">
                <span>{linkColors.range.min.toFixed(2)}</span>
                <div className="flex h-3 flex-1">
                  {COLOR_RAMPS.blueRed.map((c, i) => (
                    <div key={i} className="flex-1" style={{ backgroundColor: c }} />
                  ))}
                </div>
                <span>{linkColors.range.max.toFixed(2)}</span>
              </div>
            </div>
          )}
          {linkColors && 'legend' in linkColors && linkColors.legend && (
            <div>
              <div className="font-semibold mb-1">Links by type</div>
              <div className="grid grid-cols-2 gap-x-3 gap-y-0.5">
                {(linkColors.legend as [string, string][]).map(([type, color]) => (
                  <div key={type} className="flex items-center gap-1">
                    <div className="w-3 h-2 rounded-sm" style={{ backgroundColor: color }} />
                    <span>{type}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          {nodeColors && 'range' in nodeColors && nodeColors.range && (
            <div className={linkColors ? "border-t border-gray-700 pt-1" : ""}>
              <div className="font-semibold mb-1">Nodes: {nodeColors.field}</div>
              <div className="flex items-center gap-1">
                <span>{nodeColors.range.min.toFixed(2)}</span>
                <div className="flex h-3 flex-1">
                  {COLOR_RAMPS.greenBrown.map((c, i) => (
                    <div key={i} className="flex-1" style={{ backgroundColor: c }} />
                  ))}
                </div>
                <span>{nodeColors.range.max.toFixed(2)}</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── SVG Canvas ── */}
      <svg
        ref={svgRef}
        className="w-full h-full cursor-grab active:cursor-grabbing"
        viewBox={`${viewBox.x} ${viewBox.y} ${viewBox.w} ${viewBox.h}`}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onClick={() => { setSelectedIds(new Set()); }}
      >
        {/* Subcatchment polygons */}
        {showSubcatchments && model.subcatchments?.map(sc => {
          if (sc.points.length < 3) return null;
          const points = sc.points.map(p => `${tx(p.x)},${ty(p.y)}`).join(" ");
          const isSelected = selectedIds.has(sc.id);
          return (
            <polygon
              key={`sc-${sc.id}`}
              points={points}
              fill={isSelected ? "rgba(59,130,246,0.25)" : "rgba(34,197,94,0.08)"}
              stroke={isSelected ? "#3b82f6" : "rgba(34,197,94,0.3)"}
              strokeWidth={strokeWidth * 0.5}
              className="cursor-pointer"
              onClick={e => handleElementClick(e, sc.id, "subcatchment")}
            />
          );
        })}

        {/* Links */}
        {showLinks && model.links.map(link => {
          if (!showInactive && link.inactive) return null;
          const fromNode = nodeMap.get(link.from);
          const toNode = nodeMap.get(link.to);
          if (!fromNode || !toNode) return null;

          const isSelected = selectedIds.has(link.id);
          const color = linkColors?.map.get(link.id) || (link.inactive ? "#4b5563" : "#60a5fa");
          const opacity = link.inactive ? 0.25 : 1;

          // Build path through vertices
          const pts: { x: number; y: number }[] = [
            { x: tx(fromNode.x), y: ty(fromNode.y) },
            ...(link.vertices || []).map(v => ({ x: tx(v.x), y: ty(v.y) })),
            { x: tx(toNode.x), y: ty(toNode.y) },
          ];
          const d = pts.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");

          return (
            <g key={`link-${link.id}`}>
              {/* Hit area (wider invisible stroke) */}
              <path d={d} fill="none" stroke="transparent" strokeWidth={strokeWidth * 5}
                className="cursor-pointer"
                onClick={e => handleElementClick(e, link.id, "link")} />
              {/* Visible line */}
              <path d={d} fill="none"
                stroke={isSelected ? "#facc15" : color}
                strokeWidth={isSelected ? strokeWidth * 2.5 : strokeWidth * 1.5}
                strokeDasharray={link.inactive ? `${strokeWidth * 3} ${strokeWidth * 2}` : "none"}
                opacity={opacity}
                className="cursor-pointer pointer-events-none" />
              {/* Label */}
              {showLabels && !link.inactive && (
                <text
                  x={(pts[0].x + pts[pts.length - 1].x) / 2}
                  y={(pts[0].y + pts[pts.length - 1].y) / 2 - fontSize * 0.5}
                  fontSize={fontSize * 0.8}
                  fill="#9ca3af"
                  textAnchor="middle"
                  className="pointer-events-none select-none"
                >
                  {labelField === "diameter" ? (link.diameter ?? link.geom1 ?? "") :
                   labelField === "elevation" ? "" :
                   link.id}
                </text>
              )}
            </g>
          );
        })}

        {/* Nodes */}
        {showNodes && model.nodes.map(node => {
          if (!showInactive && node.inactive) return null;
          const isSelected = selectedIds.has(node.id);
          const defaultColor = TYPE_COLORS[node.type?.toLowerCase()] || "#60a5fa";
          const color = nodeColors?.map.get(node.id) || defaultColor;
          const cx = tx(node.x);
          const cy = ty(node.y);
          const r = isSelected ? nodeRadius * 1.8 : nodeRadius;

          return (
            <g key={`node-${node.id}`}>
              {/* Selection ring */}
              {isSelected && (
                <circle cx={cx} cy={cy} r={r * 1.5}
                  fill="none" stroke="#facc15" strokeWidth={strokeWidth} opacity={0.8} />
              )}
              {/* Node dot */}
              <circle
                cx={cx} cy={cy} r={r}
                fill={node.inactive ? "#4b5563" : color}
                stroke={isSelected ? "#facc15" : (node.inactive ? "#6b7280" : "#1e293b")}
                strokeWidth={strokeWidth * 0.5}
                opacity={node.inactive ? 0.25 : 1}
                className="cursor-pointer"
                onClick={e => handleElementClick(e, node.id, "node")}
              />
              {/* Inactive X mark */}
              {node.inactive && (
                <g opacity={0.4} className="pointer-events-none">
                  <line x1={cx - r} y1={cy - r} x2={cx + r} y2={cy + r}
                    stroke="#ef4444" strokeWidth={strokeWidth * 0.7} />
                  <line x1={cx + r} y1={cy - r} x2={cx - r} y2={cy + r}
                    stroke="#ef4444" strokeWidth={strokeWidth * 0.7} />
                </g>
              )}
              {/* Label */}
              {showLabels && !node.inactive && (
                <text
                  x={cx + r * 1.5}
                  y={cy - r * 0.5}
                  fontSize={fontSize * 0.8}
                  fill="#d1d5db"
                  className="pointer-events-none select-none"
                >
                  {labelField === "elevation" ? (node.elevation?.toFixed(1) ?? "") :
                   labelField === "diameter" ? "" :
                   node.id}
                </text>
              )}
            </g>
          );
        })}
      </svg>

      {/* ── Status bar ── */}
      <div className="absolute bottom-0 left-0 right-0 z-10 bg-gray-900/80 text-gray-400
        text-[10px] px-3 py-1 flex gap-4 border-t border-gray-800">
        <span>{model.nodes.length} nodes</span>
        <span>{model.links.length} links</span>
        <span>{model.subcatchments?.length || 0} subcatchments</span>
        {selectedIds.size > 0 && (
          <span className="text-yellow-400">{selectedIds.size} selected</span>
        )}
      </div>
    </div>
  );
}

// ── Sub-components ────────────────────────────────────────────────────

function ToolBtn({ icon, onClick, active, title }: {
  icon: React.ReactNode; onClick: () => void; active?: boolean; title: string;
}) {
  return (
    <button
      className={`w-8 h-8 flex items-center justify-center rounded-md border text-xs
        transition-colors ${active
          ? "bg-blue-600 border-blue-500 text-white"
          : "bg-gray-800/80 border-gray-700 text-gray-400 hover:text-white hover:bg-gray-700"
        }`}
      onClick={onClick}
      title={title}
    >
      {icon}
    </button>
  );
}

function LayerToggle({ label, checked, onChange, count }: {
  label: string; checked: boolean; onChange: (v: boolean) => void; count?: number;
}) {
  return (
    <label className="flex items-center gap-2 cursor-pointer hover:text-white">
      <input type="checkbox" checked={checked} onChange={e => onChange(e.target.checked)}
        className="w-3 h-3 rounded border-gray-600 bg-gray-800 accent-blue-500" />
      <span className="flex-1">{label}</span>
      {count !== undefined && (
        <span className="text-gray-500">({count})</span>
      )}
    </label>
  );
}
