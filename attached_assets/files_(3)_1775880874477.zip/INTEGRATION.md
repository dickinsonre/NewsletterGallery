# Integration Guide — All Fixes & Improvements

## Quick Summary

| # | Fix | File(s) | Effort |
|---|-----|---------|--------|
| 1 | Scenario field name mismatches (6 of 16) | `scenarioBuilder.ts` | Replace file |
| 2 | CBNODE/CBLINK uses wrong fields | `scenarioBuilder.ts` | Replace file |
| 3 | 17 missing SET pointer fields | `scenarioBuilder.ts` | Replace file |
| 4 | Editable property panel | `property-panel-editable.tsx` | Replace component |
| 5 | Merged DB Editor view | `db-editor.tsx` + `newRoutes.ts` | Add component + routes |
| 6 | Color-coding network map | `network-canvas-enhanced.tsx` | Replace component |
| 7 | Profile view | `profile-view.tsx` | Add component + tab |
| 8 | Selection sets | `selection-sets.tsx` + `newRoutes.ts` | Add component + routes |
| 9 | Map layer controls | `network-canvas-enhanced.tsx` | Included in #6 |
| 10 | Scenario comparison (within model) | `scenario-diff.tsx` + `newRoutes.ts` | Add component + routes |

---

## Step 1: Replace `server/scenarioBuilder.ts` (Fixes #1, #2, #3)

**Copy** `fixes/server/scenarioBuilder.ts` over your existing `server/scenarioBuilder.ts`.

This fixes:
- 6 field name mismatches: `JUNC_SET→JCT_SET`, `OUTF_SET→OFALL_SET`, `COND_SET→CDU_SET`,
  `ORIF_SET→ORI_SET`, `OUTL_SET→OLET_SET`, `SUBC_SET→SUBCAT_SET`
- CBNODE/CBLINK now reads actual `ID` and `TYPE` fields (not nonexistent `SETID`/`STATUS`)
- All 17 previously-missing SET pointer fields now read from SCENARIO.DBF
- New methods: `getSelectionSets()`, `compareScenarios(a, b)`

**Import changes in routes.ts**: The new `ScenarioBuilder` has the same constructor signature
but exports additional methods. No changes needed to existing route handlers.

---

## Step 2: Add New API Routes (Fixes #5, #8, #10)

Add the routes from `fixes/server/newRoutes.ts` to your `server/routes.ts`.

### In `routes.ts`, add these 4 routes:

```typescript
// IMPORTANT: Add /api/scenarios/diff/:a/:b BEFORE /api/scenarios/:id
// to prevent Express from matching "diff" as a scenario ID.

// At the top, import the new builder
import { ScenarioBuilder } from "./scenarioBuilder";

// Inside registerRoutes(), add:

// 1. Selection Sets
app.get("/api/selection-sets", (_req, res) => {
  if (!currentFiles || !Object.keys(currentFiles).length) {
    return res.json({ selections: {} });
  }
  const builder = new ScenarioBuilder(currentFiles, currentFolderType);
  res.json({ selections: builder.getSelectionSets() });
});

// 2. Scenario Diff — MUST come BEFORE /api/scenarios/:id
app.get("/api/scenarios/diff/:a/:b", (req, res) => {
  const { a, b } = req.params;
  if (!currentFiles) return res.status(400).json({ error: "No model loaded" });
  const builder = new ScenarioBuilder(currentFiles, currentFolderType);
  res.json(builder.compareScenarios(a, b));
});

// 3. Merged View (DB Editor)
app.get("/api/merged-view/:type", (req, res) => {
  // See newRoutes.ts for the full buildMergedView() function
  // Copy the function and route handler from that file
});

// 4. Edit Element Data
app.put("/api/element-data/:id", (req, res) => {
  const { id } = req.params;
  const { table, field, value } = req.body;
  // Find the record in currentFiles and update it in-memory
  // See newRoutes.ts for full implementation
});
```

---

## Step 3: Add/Replace Client Components

### 3a. Replace Network Canvas (Fix #6 + #9)

Rename your existing `network-canvas.tsx` to `network-canvas.backup.tsx`.
Copy `fixes/client/components/network-canvas-enhanced.tsx` to
`client/src/components/network-canvas.tsx` (or update the import in `home.tsx`).

In `home.tsx`, update the import:
```typescript
// Before:
import NetworkCanvas from "../components/network-canvas";
// After:
import NetworkCanvas from "../components/network-canvas-enhanced";
```

The enhanced canvas adds:
- **Color by attribute** dropdown (diameter, Manning's n, length, slope, type)
- **Layer visibility** panel (toggle nodes, links, subcatchments, labels)
- **Label display** with field selector (ID, elevation, diameter)
- **Color legend** (continuous ramp or categorical)
- **Multi-select** with Ctrl+click

### 3b. Replace Property Panel (Fix #4)

Rename `property-panel.tsx` → `property-panel.backup.tsx`.
Copy `property-panel-editable.tsx` to `client/src/components/`.

Update import in `home.tsx`:
```typescript
import PropertyPanel from "../components/property-panel-editable";
```

### 3c. Add DB Editor (Fix #5)

Copy `db-editor.tsx` to `client/src/components/`.

### 3d. Add Profile View (Fix #7)

Copy `profile-view.tsx` to `client/src/components/`.

### 3e. Add Selection Sets (Fix #8)

Copy `selection-sets.tsx` to `client/src/components/`.

### 3f. Add Scenario Diff (Fix #10)

Copy `scenario-diff.tsx` to `client/src/components/`.

---

## Step 4: Update Tab Layout in `home.tsx`

Replace the existing 8-tab layout with 11 tabs. Here's the updated tabs section:

```tsx
import DbEditor from "../components/db-editor";
import ProfileView from "../components/profile-view";
import SelectionSets from "../components/selection-sets";
import ScenarioDiff from "../components/scenario-diff";

// In the Tabs component, update the tab list and panels:

<TabsList>
  <TabsTrigger value="diagram">Network</TabsTrigger>
  <TabsTrigger value="table">Tables</TabsTrigger>
  <TabsTrigger value="dbeditor">DB Editor</TabsTrigger>      {/* NEW */}
  <TabsTrigger value="profile">Profile</TabsTrigger>          {/* NEW */}
  <TabsTrigger value="scenarios">Scenarios</TabsTrigger>
  <TabsTrigger value="scenariodiff">Scenario Diff</TabsTrigger> {/* NEW */}
  <TabsTrigger value="selections">Selections</TabsTrigger>    {/* NEW (replaces one of the lower-priority tabs or added) */}
  <TabsTrigger value="active">Status</TabsTrigger>
  <TabsTrigger value="export">SWMM5</TabsTrigger>
  <TabsTrigger value="health">Health</TabsTrigger>
  <TabsTrigger value="docs">Docs</TabsTrigger>
</TabsList>

{/* Add new tab panels */}
<TabsContent value="dbeditor" className="m-0 overflow-y-auto"
  style={{ height: 'calc(100vh - 120px)' }}>
  <DbEditor
    folderType={currentFolderType}
    onSelectElement={(id) => {
      setSelectedElement(id);
      // Optionally switch to Network tab and highlight
    }}
  />
</TabsContent>

<TabsContent value="profile" className="m-0 overflow-y-auto"
  style={{ height: 'calc(100vh - 120px)' }}>
  <ProfileView
    model={model}
    selectedElementId={selectedElement}
  />
</TabsContent>

<TabsContent value="scenariodiff" className="m-0 overflow-y-auto"
  style={{ height: 'calc(100vh - 120px)' }}>
  <ScenarioDiff
    scenarios={scenarioTree}
    onHighlightElements={(ids) => {
      // Highlight elements on network canvas
    }}
  />
</TabsContent>

<TabsContent value="selections" className="m-0 overflow-y-auto"
  style={{ height: 'calc(100vh - 120px)' }}>
  <SelectionSets
    onHighlightElements={(ids) => {
      // Highlight elements on network canvas
    }}
  />
</TabsContent>
```

---

## Step 5: Verify

1. **Load Case_Greenville** demo model
2. **Scenario tree**: Verify all 24 scenarios show correct SET pointers
   - Before fix: JCT_SET, CDU_SET, OFALL_SET etc. were silently empty
   - After fix: Values should now appear for junction, conduit, outfall scenarios
3. **Network canvas**: Use "Color By" dropdown → select "Diameter"
   - Links should color-code by size with a blue-red gradient legend
4. **DB Editor tab**: Select "Junctions" → should show merged JUNCTION+JCTHYD+NODE data
5. **Profile tab**: Click a node on the network → auto-traces downstream profile
6. **Selections tab**: Should show SEWER_SYSTEM (44 nodes) and RIVER (7 nodes)
7. **Scenario Diff tab**: Compare BASE vs SFEM → should show facility differences
   (SFEM has 194 active nodes vs 202 total)
8. **Property panel**: Click any element → double-click a field value → edit and save

---

## Files Delivered

```
fixes/
├── server/
│   ├── scenarioBuilder.ts        ← Replace existing (fixes #1, #2, #3)
│   └── newRoutes.ts              ← Add to routes.ts (fixes #5, #8, #10)
├── client/components/
│   ├── network-canvas-enhanced.tsx  ← Replace network-canvas.tsx (#6, #9)
│   ├── property-panel-editable.tsx  ← Replace property-panel.tsx (#4)
│   ├── db-editor.tsx                ← New component (#5)
│   ├── profile-view.tsx             ← New component (#7)
│   ├── selection-sets.tsx           ← New component (#8)
│   └── scenario-diff.tsx           ← New component (#10)
└── INTEGRATION.md                   ← This file
```
