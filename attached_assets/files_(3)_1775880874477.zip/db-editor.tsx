/**
 * db-editor.tsx — Merged Attribute Browser (InfoSWMM DB Editor Style)
 *
 * Instead of showing raw DBF tables, this shows "All Junctions", "All Conduits", etc.
 * with attributes merged from multiple tables (e.g., JUNCTION + JCTHYD + NODE).
 *
 * Features:
 *   - Element type selector (junctions, conduits, pumps, etc.)
 *   - Merged multi-table view
 *   - Inline editing (click cell to edit)
 *   - Sort by any column
 *   - Filter per column
 *   - CSV export
 *   - Row click → select on network map
 */

import { useState, useMemo, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Table2, Download, ArrowUpDown, Filter, Edit3, Save, X } from "lucide-react";

interface MergedRecord {
  ID: string;
  _sources: string[];
  [key: string]: any;
}

interface MergedViewData {
  type: string;
  fields: string[];
  records: MergedRecord[];
}

interface Props {
  folderType: "IEDB" | "ISDB" | "UNKNOWN";
  onSelectElement?: (id: string) => void;
}

const ISDB_TYPES = [
  { key: "junctions", label: "Junctions", icon: "⊙" },
  { key: "conduits", label: "Conduits", icon: "━" },
  { key: "outfalls", label: "Outfalls", icon: "▽" },
  { key: "storage", label: "Storage", icon: "◻" },
  { key: "pumps", label: "Pumps", icon: "⊳" },
  { key: "orifices", label: "Orifices", icon: "◎" },
  { key: "weirs", label: "Weirs", icon: "▿" },
  { key: "outlets", label: "Outlets", icon: "◇" },
  { key: "subcatchments", label: "Subcatchments", icon: "▨" },
  { key: "dividers", label: "Dividers", icon: "⋔" },
];

const IEDB_TYPES = [
  { key: "manholes", label: "Manholes", icon: "⊙" },
  { key: "pipes", label: "Pipes", icon: "━" },
  { key: "wetwells", label: "Wet Wells", icon: "◻" },
  { key: "pumps", label: "Pumps", icon: "⊳" },
];

export default function DbEditor({ folderType, onSelectElement }: Props) {
  const queryClient = useQueryClient();
  const elementTypes = folderType === "IEDB" ? IEDB_TYPES : ISDB_TYPES;
  const [selectedType, setSelectedType] = useState(elementTypes[0].key);
  const [sortField, setSortField] = useState<string>("ID");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [showFilters, setShowFilters] = useState(false);
  const [editCell, setEditCell] = useState<{ id: string; field: string } | null>(null);
  const [editValue, setEditValue] = useState("");
  const [selectedRow, setSelectedRow] = useState<string | null>(null);

  // Fetch merged view
  const { data, isLoading } = useQuery({
    queryKey: ["merged-view", selectedType],
    queryFn: async () => {
      const res = await fetch(`/api/merged-view/${selectedType}`);
      if (!res.ok) throw new Error("Failed to load merged view");
      return res.json() as Promise<MergedViewData>;
    },
  });

  // Save mutation
  const saveMutation = useMutation({
    mutationFn: async (params: { id: string; field: string; value: string; table: string }) => {
      const res = await fetch(`/api/element-data/${encodeURIComponent(params.id)}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ table: params.table, field: params.field, value: params.value }),
      });
      if (!res.ok) throw new Error("Save failed");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["merged-view", selectedType] });
    },
  });

  // Determine visible fields (skip internal fields, reorder meaningfully)
  const visibleFields = useMemo(() => {
    if (!data?.fields) return [];
    const priority = ["ID", "ELEVATION", "INV_ELEV", "MAX_DEPTH", "DIAMETER", "LENGTH",
      "MANNING", "ROUGHNESS", "COEFF", "SLOPE", "FROM", "TO", "TYPE", "AREA", "PERIMP"];
    const rest = data.fields.filter(f => !priority.includes(f) && f !== "_sources" && f !== "ID");
    return ["ID", ...priority.filter(f => data.fields.includes(f) && f !== "ID"), ...rest];
  }, [data?.fields]);

  // Sort and filter records
  const displayRecords = useMemo(() => {
    if (!data?.records) return [];
    let records = [...data.records];

    // Apply filters
    for (const [field, filterVal] of Object.entries(filters)) {
      if (!filterVal) continue;
      const lower = filterVal.toLowerCase();
      records = records.filter(r => String(r[field] ?? "").toLowerCase().includes(lower));
    }

    // Sort
    records.sort((a, b) => {
      const va = a[sortField] ?? "";
      const vb = b[sortField] ?? "";
      const numA = parseFloat(va);
      const numB = parseFloat(vb);
      if (!isNaN(numA) && !isNaN(numB)) {
        return sortDir === "asc" ? numA - numB : numB - numA;
      }
      const cmp = String(va).localeCompare(String(vb));
      return sortDir === "asc" ? cmp : -cmp;
    });

    return records;
  }, [data?.records, filters, sortField, sortDir]);

  const handleSort = useCallback((field: string) => {
    if (sortField === field) {
      setSortDir(d => d === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDir("asc");
    }
  }, [sortField]);

  const handleRowClick = useCallback((id: string) => {
    setSelectedRow(id);
    onSelectElement?.(id);
  }, [onSelectElement]);

  const startEdit = useCallback((id: string, field: string, value: any) => {
    setEditCell({ id, field });
    setEditValue(String(value ?? ""));
  }, []);

  const saveCell = useCallback(() => {
    if (!editCell || !data) return;
    // Determine which source table owns this field
    const record = data.records.find(r => r.ID === editCell.id);
    const table = record?._sources?.[0] || selectedType.toUpperCase();
    saveMutation.mutate({ id: editCell.id, field: editCell.field, value: editValue, table });
    setEditCell(null);
  }, [editCell, editValue, data, selectedType, saveMutation]);

  const exportCSV = useCallback(() => {
    if (!displayRecords.length) return;
    const fields = visibleFields;
    const header = fields.join(",");
    const rows = displayRecords.map(r =>
      fields.map(f => {
        const v = String(r[f] ?? "").replace(/"/g, '""');
        return v.includes(",") ? `"${v}"` : v;
      }).join(",")
    );
    const csv = [header, ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${selectedType}.csv`; a.click();
  }, [displayRecords, visibleFields, selectedType]);

  return (
    <div className="h-full flex flex-col">
      {/* Toolbar */}
      <div className="flex items-center gap-2 px-3 py-2 border-b bg-white dark:bg-gray-800
        dark:border-gray-700 flex-wrap">
        <Table2 size={16} className="text-blue-500" />
        <span className="font-semibold text-sm text-gray-700 dark:text-gray-200">DB Editor</span>

        {/* Element type buttons */}
        <div className="flex gap-0.5 flex-wrap ml-2">
          {elementTypes.map(et => (
            <button
              key={et.key}
              className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
                selectedType === et.key
                  ? "bg-blue-600 text-white font-medium"
                  : "bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"
              }`}
              onClick={() => setSelectedType(et.key)}
            >
              <span className="mr-1">{et.icon}</span>{et.label}
            </button>
          ))}
        </div>

        <div className="flex-1" />

        <button onClick={() => setShowFilters(v => !v)}
          className={`p-1.5 rounded ${showFilters ? "text-blue-500" : "text-gray-400"} hover:text-blue-600`}
          title="Toggle column filters">
          <Filter size={14} />
        </button>
        <button onClick={exportCSV}
          className="p-1.5 rounded text-gray-400 hover:text-green-500"
          title="Export CSV">
          <Download size={14} />
        </button>
        <span className="text-xs text-gray-400">
          {displayRecords.length} / {data?.records?.length ?? 0} records
        </span>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto">
        {isLoading ? (
          <div className="p-4 text-sm text-gray-500">Loading {selectedType}...</div>
        ) : displayRecords.length === 0 ? (
          <div className="p-6 text-center text-gray-400 text-sm">
            No {selectedType} found in model
          </div>
        ) : (
          <table className="text-xs border-collapse w-full">
            <thead className="sticky top-0 z-10">
              <tr className="bg-gray-100 dark:bg-gray-800">
                {visibleFields.map(field => (
                  <th key={field} className="px-2 py-1.5 text-left font-semibold text-gray-600
                    dark:text-gray-300 border-b dark:border-gray-700 whitespace-nowrap cursor-pointer
                    hover:bg-gray-200 dark:hover:bg-gray-700 select-none"
                    onClick={() => handleSort(field)}>
                    <div className="flex items-center gap-1">
                      {field}
                      {sortField === field && (
                        <ArrowUpDown size={10} className={`text-blue-500 ${
                          sortDir === "desc" ? "rotate-180" : ""
                        }`} />
                      )}
                    </div>
                  </th>
                ))}
              </tr>
              {showFilters && (
                <tr className="bg-gray-50 dark:bg-gray-850">
                  {visibleFields.map(field => (
                    <th key={`f-${field}`} className="px-1 py-1">
                      <input
                        className="w-full bg-white dark:bg-gray-800 border border-gray-200
                          dark:border-gray-600 rounded px-1.5 py-0.5 text-xs font-normal"
                        placeholder="filter..."
                        value={filters[field] || ""}
                        onChange={e => setFilters(prev => ({ ...prev, [field]: e.target.value }))}
                      />
                    </th>
                  ))}
                </tr>
              )}
            </thead>
            <tbody>
              {displayRecords.map((record, ri) => (
                <tr
                  key={record.ID || ri}
                  className={`border-b border-gray-50 dark:border-gray-800 cursor-pointer ${
                    selectedRow === record.ID
                      ? "bg-blue-50 dark:bg-blue-900/30"
                      : ri % 2 === 0
                        ? "bg-white dark:bg-gray-900"
                        : "bg-gray-50/50 dark:bg-gray-850"
                  } hover:bg-blue-50/50 dark:hover:bg-blue-900/20`}
                  onClick={() => handleRowClick(record.ID)}
                >
                  {visibleFields.map(field => {
                    const isEditing = editCell?.id === record.ID && editCell?.field === field;
                    const value = record[field];

                    return (
                      <td key={field} className="px-2 py-1 font-mono whitespace-nowrap">
                        {isEditing ? (
                          <div className="flex items-center gap-0.5">
                            <input
                              className="w-full bg-white dark:bg-gray-800 border border-blue-400
                                rounded px-1 py-0 text-xs focus:outline-none"
                              value={editValue}
                              autoFocus
                              onChange={e => setEditValue(e.target.value)}
                              onKeyDown={e => {
                                if (e.key === "Enter") saveCell();
                                if (e.key === "Escape") setEditCell(null);
                              }}
                            />
                            <button onClick={saveCell} className="text-green-500"><Save size={10}/></button>
                            <button onClick={() => setEditCell(null)} className="text-gray-400"><X size={10}/></button>
                          </div>
                        ) : (
                          <span
                            className="hover:text-blue-600 dark:hover:text-blue-400"
                            onDoubleClick={(e) => {
                              e.stopPropagation();
                              if (field !== "ID") startEdit(record.ID, field, value);
                            }}
                            title={field !== "ID" ? "Double-click to edit" : undefined}
                          >
                            {value ?? <span className="text-gray-300 italic">—</span>}
                          </span>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
