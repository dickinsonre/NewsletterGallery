/**
 * scenario-diff.tsx — Within-Model Scenario Comparison
 *
 * Compare two scenarios from the same model: shows SET pointer diffs,
 * active element differences, and attribute override differences.
 * This replaces the model-compare.tsx (which compared two loaded models)
 * with a far more useful scenario-vs-scenario comparison.
 */

import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { GitCompare, ChevronDown, ChevronRight, AlertTriangle, ArrowRight } from "lucide-react";

interface ScenarioNode {
  id: string;
  children: ScenarioNode[];
}

interface DiffResult {
  scenarioA: string;
  scenarioB: string;
  chainA: string[];
  chainB: string[];
  setDiffs: { field: string; valueA: string; valueB: string }[];
  facilityDiffs: {
    onlyInA_nodes: string[];
    onlyInB_nodes: string[];
    onlyInA_links: string[];
    onlyInB_links: string[];
  };
  attributeDiffs: Record<string, { field: string; id: string; valueA: any; valueB: any }[]>;
}

interface Props {
  scenarios: ScenarioNode[];
  onHighlightElements?: (ids: string[]) => void;
}

// Flatten scenario tree into list
function flattenScenarios(nodes: ScenarioNode[], prefix = ""): string[] {
  const result: string[] = [];
  for (const node of nodes) {
    result.push(node.id);
    result.push(...flattenScenarios(node.children));
  }
  return result;
}

export default function ScenarioDiff({ scenarios, onHighlightElements }: Props) {
  const scenarioList = useMemo(() => flattenScenarios(scenarios), [scenarios]);
  const [scenarioA, setScenarioA] = useState(scenarioList[0] || "");
  const [scenarioB, setScenarioB] = useState(scenarioList[1] || "");
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(["sets", "facility"]));

  const canCompare = scenarioA && scenarioB && scenarioA !== scenarioB;

  const { data: diff, isLoading, error } = useQuery({
    queryKey: ["scenario-diff", scenarioA, scenarioB],
    queryFn: async () => {
      const res = await fetch(`/api/scenarios/diff/${encodeURIComponent(scenarioA)}/${encodeURIComponent(scenarioB)}`);
      if (!res.ok) throw new Error("Failed to compare scenarios");
      return res.json() as Promise<DiffResult>;
    },
    enabled: canCompare,
  });

  const toggleSection = (s: string) => {
    setExpandedSections(prev => {
      const next = new Set(prev);
      if (next.has(s)) next.delete(s); else next.add(s);
      return next;
    });
  };

  const totalFacilityDiffs = diff ? (
    diff.facilityDiffs.onlyInA_nodes.length +
    diff.facilityDiffs.onlyInB_nodes.length +
    diff.facilityDiffs.onlyInA_links.length +
    diff.facilityDiffs.onlyInB_links.length
  ) : 0;

  const totalAttrDiffs = diff
    ? Object.values(diff.attributeDiffs).reduce((acc, diffs) => acc + diffs.length, 0)
    : 0;

  return (
    <div className="h-full overflow-y-auto">
      {/* Selector */}
      <div className="sticky top-0 z-10 bg-white dark:bg-gray-900 border-b dark:border-gray-700 p-3">
        <div className="flex items-center gap-2 flex-wrap">
          <GitCompare size={16} className="text-purple-500" />
          <span className="font-semibold text-sm text-gray-700 dark:text-gray-200">
            Compare Scenarios
          </span>
        </div>
        <div className="flex items-center gap-2 mt-2">
          <select
            className="flex-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600
              rounded-md px-3 py-1.5 text-sm"
            value={scenarioA}
            onChange={e => setScenarioA(e.target.value)}
          >
            {scenarioList.map(s => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
          <ArrowRight size={16} className="text-gray-400 shrink-0" />
          <select
            className="flex-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600
              rounded-md px-3 py-1.5 text-sm"
            value={scenarioB}
            onChange={e => setScenarioB(e.target.value)}
          >
            {scenarioList.map(s => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>

        {scenarioA === scenarioB && scenarioA && (
          <p className="text-xs text-amber-500 mt-1 flex items-center gap-1">
            <AlertTriangle size={12} /> Select two different scenarios
          </p>
        )}
      </div>

      {isLoading && canCompare && (
        <div className="p-4 text-sm text-gray-500">Comparing {scenarioA} vs {scenarioB}...</div>
      )}

      {error && (
        <div className="p-4 text-sm text-red-500">Error: {(error as Error).message}</div>
      )}

      {diff && (
        <div className="divide-y dark:divide-gray-800">
          {/* Summary */}
          <div className="p-3 bg-gray-50 dark:bg-gray-800/50">
            <div className="grid grid-cols-3 gap-3 text-center text-xs">
              <div className="bg-white dark:bg-gray-800 rounded-lg p-2 shadow-sm">
                <div className="text-lg font-bold text-purple-600">{diff.setDiffs.length}</div>
                <div className="text-gray-500">SET Diffs</div>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-lg p-2 shadow-sm">
                <div className="text-lg font-bold text-amber-600">{totalFacilityDiffs}</div>
                <div className="text-gray-500">Facility Diffs</div>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-lg p-2 shadow-sm">
                <div className="text-lg font-bold text-blue-600">{totalAttrDiffs}</div>
                <div className="text-gray-500">Attribute Diffs</div>
              </div>
            </div>

            {/* Inheritance chains */}
            <div className="mt-2 text-xs text-gray-500 space-y-0.5">
              <div><span className="font-medium">{scenarioA}:</span> {diff.chainA.join(" → ")}</div>
              <div><span className="font-medium">{scenarioB}:</span> {diff.chainB.join(" → ")}</div>
            </div>
          </div>

          {/* SET Pointer Differences */}
          <SectionHeader
            title="Dataset (SET) Differences"
            count={diff.setDiffs.length}
            expanded={expandedSections.has("sets")}
            onToggle={() => toggleSection("sets")}
          />
          {expandedSections.has("sets") && diff.setDiffs.length > 0 && (
            <div className="px-3 pb-3">
              <table className="w-full text-xs border-collapse">
                <thead>
                  <tr className="text-gray-500">
                    <th className="text-left py-1 font-medium">SET Field</th>
                    <th className="text-left py-1 font-medium">{scenarioA}</th>
                    <th className="text-left py-1 font-medium">{scenarioB}</th>
                  </tr>
                </thead>
                <tbody>
                  {diff.setDiffs.map(d => (
                    <tr key={d.field} className="border-t border-gray-100 dark:border-gray-800">
                      <td className="py-1 font-mono text-gray-700 dark:text-gray-300">{d.field}</td>
                      <td className="py-1 font-mono">
                        <span className={d.valueA ? "text-blue-600" : "text-gray-300 italic"}>
                          {d.valueA || "—"}
                        </span>
                      </td>
                      <td className="py-1 font-mono">
                        <span className={d.valueB ? "text-green-600" : "text-gray-300 italic"}>
                          {d.valueB || "—"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Facility (Active Element) Differences */}
          <SectionHeader
            title="Active Element Differences"
            count={totalFacilityDiffs}
            expanded={expandedSections.has("facility")}
            onToggle={() => toggleSection("facility")}
          />
          {expandedSections.has("facility") && totalFacilityDiffs > 0 && (
            <div className="px-3 pb-3 text-xs space-y-2">
              {diff.facilityDiffs.onlyInA_nodes.length > 0 && (
                <DiffGroup
                  label={`Nodes only in ${scenarioA}`}
                  ids={diff.facilityDiffs.onlyInA_nodes}
                  color="blue"
                  onHighlight={onHighlightElements}
                />
              )}
              {diff.facilityDiffs.onlyInB_nodes.length > 0 && (
                <DiffGroup
                  label={`Nodes only in ${scenarioB}`}
                  ids={diff.facilityDiffs.onlyInB_nodes}
                  color="green"
                  onHighlight={onHighlightElements}
                />
              )}
              {diff.facilityDiffs.onlyInA_links.length > 0 && (
                <DiffGroup
                  label={`Links only in ${scenarioA}`}
                  ids={diff.facilityDiffs.onlyInA_links}
                  color="blue"
                  onHighlight={onHighlightElements}
                />
              )}
              {diff.facilityDiffs.onlyInB_links.length > 0 && (
                <DiffGroup
                  label={`Links only in ${scenarioB}`}
                  ids={diff.facilityDiffs.onlyInB_links}
                  color="green"
                  onHighlight={onHighlightElements}
                />
              )}
            </div>
          )}

          {/* Attribute Differences */}
          {Object.entries(diff.attributeDiffs).map(([tableName, diffs]) => (
            <div key={tableName}>
              <SectionHeader
                title={`${tableName} Attribute Diffs`}
                count={diffs.length}
                expanded={expandedSections.has(tableName)}
                onToggle={() => toggleSection(tableName)}
              />
              {expandedSections.has(tableName) && (
                <div className="px-3 pb-3">
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr className="text-gray-500">
                        <th className="text-left py-1 font-medium">ID</th>
                        <th className="text-left py-1 font-medium">Field</th>
                        <th className="text-left py-1 font-medium">{scenarioA}</th>
                        <th className="text-left py-1 font-medium">{scenarioB}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {diffs.slice(0, 100).map((d, i) => (
                        <tr key={i} className="border-t border-gray-100 dark:border-gray-800">
                          <td className="py-1 font-mono">{d.id}</td>
                          <td className="py-1 font-mono text-gray-500">{d.field}</td>
                          <td className="py-1 font-mono text-blue-600">{d.valueA}</td>
                          <td className="py-1 font-mono text-green-600">{d.valueB}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {diffs.length > 100 && (
                    <p className="text-gray-400 text-xs mt-1">
                      Showing 100 of {diffs.length} differences
                    </p>
                  )}
                </div>
              )}
            </div>
          ))}

          {diff.setDiffs.length === 0 && totalFacilityDiffs === 0 && totalAttrDiffs === 0 && (
            <div className="p-6 text-center text-gray-400 text-sm">
              These scenarios are identical
            </div>
          )}
        </div>
      )}

      {!canCompare && !diff && (
        <div className="p-6 text-center text-gray-400 text-sm">
          <GitCompare size={32} className="mx-auto mb-2 opacity-50" />
          <p>Select two different scenarios to compare</p>
        </div>
      )}
    </div>
  );
}

// ── Sub-components ────────────────────────────────────────────────────

function SectionHeader({ title, count, expanded, onToggle }: {
  title: string; count: number; expanded: boolean; onToggle: () => void;
}) {
  return (
    <button
      className="w-full flex items-center gap-2 px-3 py-2 text-sm font-medium
        text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-800"
      onClick={onToggle}
    >
      {expanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
      <span className="flex-1 text-left">{title}</span>
      {count > 0 && (
        <span className="bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300
          text-xs px-2 py-0.5 rounded-full">{count}</span>
      )}
    </button>
  );
}

function DiffGroup({ label, ids, color, onHighlight }: {
  label: string; ids: string[]; color: "blue" | "green";
  onHighlight?: (ids: string[]) => void;
}) {
  const colorClass = color === "blue" ? "text-blue-600" : "text-green-600";
  const bgClass = color === "blue" ? "bg-blue-50 dark:bg-blue-950/30" : "bg-green-50 dark:bg-green-950/30";
  return (
    <div className={`rounded-md p-2 ${bgClass}`}>
      <div className="flex items-center justify-between mb-1">
        <span className={`font-medium ${colorClass}`}>{label} ({ids.length})</span>
        {onHighlight && (
          <button onClick={() => onHighlight(ids)}
            className="text-xs text-gray-400 hover:text-blue-500">
            Highlight on map
          </button>
        )}
      </div>
      <div className="font-mono text-gray-600 dark:text-gray-400">
        {ids.slice(0, 30).join(", ")}
        {ids.length > 30 && ` ... +${ids.length - 30} more`}
      </div>
    </div>
  );
}
