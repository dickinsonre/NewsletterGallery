/**
 * scenarioBuilder.ts — FIXED VERSION
 * 
 * Fixes applied:
 *   FIX #1: 6 field name mismatches corrected (JUNC_SET→JCT_SET, etc.)
 *   FIX #2: CBNODE/CBLINK — uses actual fields (ID, TYPE) not (SETID, STATUS)
 *   FIX #3: 17 missing SET pointer fields now read from SCENARIO.DBF
 */

import type { DbfFileData } from "./dbfReader";

// ── Types ──────────────────────────────────────────────────────────────

export interface ScenarioNode {
  id: string;
  parent: string;
  description: string;
  facType: number;            // 0 = inherited, 1 = custom, 3 = partial
  children: ScenarioNode[];
  sets: ResolvedSets;
  activeNodes: number;
  activeLinks: number;
  inactiveNodes: number;
  inactiveLinks: number;
}

export interface ResolvedSets {
  // ── Facility / Option / Climate / Report ──
  facilityType: string;
  querySet: string;
  useClimate: string;
  climateSet: string;
  useReport: string;
  reportSet: string;
  useOption: string;
  optionSet: string;

  // ── Node attribute SETs ── (FIX #1: corrected field names)
  jctSet: string;          // was JUNC_SET → actual field: JCT_SET
  divSet: string;          // FIX #3: was missing
  ofallSet: string;        // was OUTF_SET → actual field: OFALL_SET
  storSet: string;
  subcatSet: string;       // was SUBC_SET → actual field: SUBCAT_SET

  // ── Link attribute SETs ──
  cduSet: string;          // was COND_SET → actual field: CDU_SET
  pumpSet: string;
  oriSet: string;          // was ORIF_SET → actual field: ORI_SET
  weirSet: string;
  oletSet: string;         // was OUTL_SET → actual field: OLET_SET

  // ── Hydrology & Loading SETs ──
  dwfSet: string;
  rdiiSet: string;
  iflowSet: string;        // FIX #3: was missing (external inflows)
  treatSet: string;
  qualSet: string;
  gwSet: string;
  snowSet: string;
  lidSet: string;
  sublidSet: string;       // FIX #3: was missing

  // ── Environmental / Parameter SETs ── (FIX #3: all were missing)
  coverSet: string;
  infilSet: string;
  statsSet: string;
  ctrlSet: string;
  soilSet: string;
  aquifSet: string;
  luSet: string;
  polluSet: string;
  hydghSet: string;
  ruleSet: string;
  patnSet: string;
  curveSet: string;
  tsSet: string;
  rgageSet: string;
  wqSet: string;
}

export interface ActiveElementStatus {
  id: string;
  type: string;
  status: "ACTIVE" | "INACTIVE" | "OUT_OF_DOMAIN";
  reason: string;
}

export interface ScenarioResolution {
  chain: string[];
  resolvedSets: ResolvedSets;
  facilityOverrides: { nodes: string[]; links: string[] };
  attributeOverrides: Record<string, any[]>;
}

export interface ActiveStatusResult {
  scenarioId: string;
  summary: {
    totalNodes: number;
    totalLinks: number;
    activeNodes: number;
    activeLinks: number;
    inactiveNodes: number;
    inactiveLinks: number;
    outOfDomainNodes: number;
    outOfDomainLinks: number;
  };
  nodes: ActiveElementStatus[];
  links: ActiveElementStatus[];
}

// ── Helpers ────────────────────────────────────────────────────────────

function getField(record: any, field: string): string {
  // Case-insensitive field lookup — DBF field names can vary in case
  const val =
    record[field] ??
    record[field.toUpperCase()] ??
    record[field.toLowerCase()] ??
    "";
  return String(val).trim();
}

function getTable(
  files: Record<string, DbfFileData>,
  ...names: string[]
): any[] {
  for (const name of names) {
    // Try exact key
    if (files[name]?.records) return files[name].records;
    // Try uppercase
    const upper = name.toUpperCase();
    if (files[upper]?.records) return files[upper].records;
    // Try with .dbf extension variations
    const withDbf = name.endsWith(".dbf") ? name : `${name}.dbf`;
    if (files[withDbf]?.records) return files[withDbf].records;
    // Search all keys for case-insensitive match
    for (const key of Object.keys(files)) {
      if (key.toUpperCase() === upper || key.toUpperCase() === upper + ".DBF") {
        return files[key].records;
      }
    }
    // Subfolder search (e.g., "Scenario/BASE/ANODE")
    for (const key of Object.keys(files)) {
      const parts = key.split("/");
      const last = parts[parts.length - 1].replace(/\.dbf$/i, "");
      if (last.toUpperCase() === name.toUpperCase().replace(/\.dbf$/i, "")) {
        return files[key].records;
      }
    }
  }
  return [];
}

function getSubfolderTable(
  files: Record<string, DbfFileData>,
  folder: string,
  subfolder: string,
  tableName: string
): any[] {
  // Try: Folder/Subfolder/TABLE.dbf (case variations)
  const candidates = [
    `${folder}/${subfolder}/${tableName}`,
    `${folder}/${subfolder}/${tableName}.dbf`,
    `${folder}/${subfolder}/${tableName.toUpperCase()}`,
    `${folder}/${subfolder}/${tableName.toUpperCase()}.dbf`,
  ];
  for (const key of candidates) {
    if (files[key]?.records) return files[key].records;
  }
  // Fallback: case-insensitive full scan
  const target = `${folder}/${subfolder}/${tableName}`
    .toUpperCase()
    .replace(/\.DBF$/, "");
  for (const key of Object.keys(files)) {
    if (key.toUpperCase().replace(/\.DBF$/, "") === target) {
      return files[key].records;
    }
  }
  return [];
}

// ── Empty sets factory ─────────────────────────────────────────────────

function emptySets(): ResolvedSets {
  return {
    facilityType: "",
    querySet: "",
    useClimate: "",
    climateSet: "",
    useReport: "",
    reportSet: "",
    useOption: "",
    optionSet: "",
    jctSet: "",
    divSet: "",
    ofallSet: "",
    storSet: "",
    subcatSet: "",
    cduSet: "",
    pumpSet: "",
    oriSet: "",
    weirSet: "",
    oletSet: "",
    dwfSet: "",
    rdiiSet: "",
    iflowSet: "",
    treatSet: "",
    qualSet: "",
    gwSet: "",
    snowSet: "",
    lidSet: "",
    sublidSet: "",
    coverSet: "",
    infilSet: "",
    statsSet: "",
    ctrlSet: "",
    soilSet: "",
    aquifSet: "",
    luSet: "",
    polluSet: "",
    hydghSet: "",
    ruleSet: "",
    patnSet: "",
    curveSet: "",
    tsSet: "",
    rgageSet: "",
    wqSet: "",
  };
}

// ── Main class ─────────────────────────────────────────────────────────

export class ScenarioBuilder {
  private files: Record<string, DbfFileData>;
  private folderType: "IEDB" | "ISDB" | "UNKNOWN";

  constructor(
    files: Record<string, DbfFileData>,
    folderType: "IEDB" | "ISDB" | "UNKNOWN"
  ) {
    this.files = files;
    this.folderType = folderType;
  }

  // ── Build scenario tree ─────────────────────────────────────────────

  buildTree(): ScenarioNode[] {
    const scenarios = getTable(this.files, "SCENARIO");
    if (!scenarios.length) return [];

    // Build lookup by ID
    const lookup = new Map<string, any>();
    for (const rec of scenarios) {
      const id = getField(rec, "ID");
      if (id) lookup.set(id, rec);
    }

    // Build nodes
    const nodeMap = new Map<string, ScenarioNode>();
    for (const [id, rec] of lookup) {
      const sets = this.extractSets(rec);
      const facType = parseInt(getField(rec, "FAC_TYPE") || "0", 10);

      // Count active/inactive for this scenario
      const counts = this.countActiveInactive(
        getField(rec, "QUERY_SET"),
        id
      );

      nodeMap.set(id, {
        id,
        parent: getField(rec, "PARENT"),
        description: getField(rec, "DESCRIPT"),
        facType,
        children: [],
        sets,
        activeNodes: counts.activeNodes,
        activeLinks: counts.activeLinks,
        inactiveNodes: counts.inactiveNodes,
        inactiveLinks: counts.inactiveLinks,
      });
    }

    // Wire parent-child
    const roots: ScenarioNode[] = [];
    for (const node of nodeMap.values()) {
      if (node.parent && nodeMap.has(node.parent)) {
        nodeMap.get(node.parent)!.children.push(node);
      } else {
        roots.push(node);
      }
    }

    return roots;
  }

  // ── FIX #1 + FIX #3: Extract all SET pointers with correct field names ──

  extractSets(record: any): ResolvedSets {
    return {
      facilityType: getField(record, "FAC_TYPE"),
      querySet: getField(record, "QUERY_SET"),
      useClimate: getField(record, "USECLIMATE"),
      climateSet: getField(record, "CLIMATESET"),
      useReport: getField(record, "USE_REPORT"),
      reportSet: getField(record, "REPORT_SET"),
      useOption: getField(record, "USE_OPTION"),
      optionSet: getField(record, "OPTION_SET"),

      // FIX #1: Corrected field names to match actual SCENARIO.DBF columns
      jctSet: getField(record, "JCT_SET"),         // was JUNC_SET ❌ → JCT_SET ✅
      divSet: getField(record, "DIV_SET"),          // FIX #3: was missing
      ofallSet: getField(record, "OFALL_SET"),      // was OUTF_SET ❌ → OFALL_SET ✅
      storSet: getField(record, "STOR_SET"),
      subcatSet: getField(record, "SUBCAT_SET"),    // was SUBC_SET ❌ → SUBCAT_SET ✅

      cduSet: getField(record, "CDU_SET"),          // was COND_SET ❌ → CDU_SET ✅
      pumpSet: getField(record, "PUMP_SET"),
      oriSet: getField(record, "ORI_SET"),          // was ORIF_SET ❌ → ORI_SET ✅
      weirSet: getField(record, "WEIR_SET"),
      oletSet: getField(record, "OLET_SET"),        // was OUTL_SET ❌ → OLET_SET ✅

      dwfSet: getField(record, "DWF_SET"),
      rdiiSet: getField(record, "RDII_SET"),
      iflowSet: getField(record, "IFLOW_SET"),      // FIX #3: was missing
      treatSet: getField(record, "TREAT_SET"),
      qualSet: getField(record, "QUAL_SET"),
      gwSet: getField(record, "GW_SET"),
      snowSet: getField(record, "SNOW_SET"),
      lidSet: getField(record, "LID_SET"),
      sublidSet: getField(record, "SUBLID_SET"),    // FIX #3: was missing

      // FIX #3: All 17 previously missing SET pointer fields
      coverSet: getField(record, "COVER_SET"),
      infilSet: getField(record, "INFIL_SET"),
      statsSet: getField(record, "STATS_SET"),
      ctrlSet: getField(record, "CTRL_SET"),
      soilSet: getField(record, "SOIL_SET"),
      aquifSet: getField(record, "AQUIF_SET"),
      luSet: getField(record, "LU_SET"),
      polluSet: getField(record, "POLLU_SET"),
      hydghSet: getField(record, "HYDGH_SET"),
      ruleSet: getField(record, "RULE_SET"),
      patnSet: getField(record, "PATN_SET"),
      curveSet: getField(record, "CURVE_SET"),
      tsSet: getField(record, "TS_SET"),
      rgageSet: getField(record, "RGAGE_SET"),
      wqSet: getField(record, "WQ_SET"),
    };
  }

  // ── FIX #2: CBNODE/CBLINK — use actual fields (ID, TYPE) not (SETID, STATUS) ──

  countActiveInactive(
    facilitySet: string,
    scenarioId: string
  ): {
    activeNodes: number;
    activeLinks: number;
    inactiveNodes: number;
    inactiveLinks: number;
  } {
    // Get total element counts from NODE and LINK tables
    const allNodes = getTable(this.files, "NODE");
    const allLinks = getTable(this.files, "LINK");
    const totalNodes = allNodes.length;
    const totalLinks = allLinks.length;

    // Strategy 1: Check scenario subfolder ANODE/ALINK first (more reliable)
    const scenarioANodes = getSubfolderTable(
      this.files,
      "Scenario",
      scenarioId,
      "ANODE"
    );
    const scenarioALinks = getSubfolderTable(
      this.files,
      "Scenario",
      scenarioId,
      "ALINK"
    );

    if (scenarioANodes.length > 0 || scenarioALinks.length > 0) {
      // Scenario subfolder has active element lists
      // Empty file = all active; populated = only listed IDs are active
      const activeN = scenarioANodes.length > 0 ? scenarioANodes.length : totalNodes;
      const activeL = scenarioALinks.length > 0 ? scenarioALinks.length : totalLinks;
      return {
        activeNodes: activeN,
        activeLinks: activeL,
        inactiveNodes: totalNodes - activeN,
        inactiveLinks: totalLinks - activeL,
      };
    }

    // Strategy 2: Check CBNODE/CBLINK tables
    // FIX #2: Actual fields are ID and TYPE, NOT SETID and STATUS
    const cbNodes = getTable(this.files, "CBNODE");
    const cbLinks = getTable(this.files, "CBLINK");

    if (cbNodes.length > 0 || cbLinks.length > 0) {
      // CBNODE/CBLINK contain combined active element lists
      // Each record has ID (element id) and TYPE (element type code)
      // All elements in CBNODE are considered active in the combined scenario
      const activeN = cbNodes.length > 0 ? cbNodes.length : totalNodes;
      const activeL = cbLinks.length > 0 ? cbLinks.length : totalLinks;
      return {
        activeNodes: activeN,
        activeLinks: activeL,
        inactiveNodes: totalNodes - activeN,
        inactiveLinks: totalLinks - activeL,
      };
    }

    // Strategy 3: Check base ANODE/ALINK
    const baseANodes = getTable(this.files, "ANODE");
    const baseALinks = getTable(this.files, "ALINK");

    if (baseANodes.length > 0) {
      const activeN = baseANodes.length;
      const activeL = baseALinks.length > 0 ? baseALinks.length : totalLinks;
      return {
        activeNodes: activeN,
        activeLinks: activeL,
        inactiveNodes: totalNodes - activeN,
        inactiveLinks: totalLinks - activeL,
      };
    }

    // Default: all active
    return {
      activeNodes: totalNodes,
      activeLinks: totalLinks,
      inactiveNodes: 0,
      inactiveLinks: 0,
    };
  }

  // ── Resolve scenario inheritance chain ──────────────────────────────

  resolveScenario(scenarioId: string): ScenarioResolution {
    const scenarios = getTable(this.files, "SCENARIO");
    const lookup = new Map<string, any>();
    for (const rec of scenarios) {
      const id = getField(rec, "ID");
      if (id) lookup.set(id, rec);
    }

    // Walk the chain from child to root
    const chain: string[] = [];
    let current = scenarioId;
    const visited = new Set<string>();
    while (current && lookup.has(current) && !visited.has(current)) {
      visited.add(current);
      chain.unshift(current);
      current = getField(lookup.get(current), "PARENT");
    }

    // Merge sets: parent first, child overrides non-empty values
    const resolved = emptySets();
    for (const id of chain) {
      const rec = lookup.get(id);
      if (!rec) continue;
      const sets = this.extractSets(rec);
      for (const key of Object.keys(sets) as (keyof ResolvedSets)[]) {
        if (sets[key]) {
          (resolved as any)[key] = sets[key];
        }
      }
    }

    // Resolve facility overrides (active element lists)
    const facilityOverrides = this.resolveFacilityOverrides(scenarioId);

    // Resolve attribute overrides from SET files
    const attributeOverrides = this.resolveAttributeOverrides(resolved);

    return {
      chain,
      resolvedSets: resolved,
      facilityOverrides,
      attributeOverrides,
    };
  }

  // ── Facility overrides (which elements are active) ──────────────────

  private resolveFacilityOverrides(
    scenarioId: string
  ): { nodes: string[]; links: string[] } {
    // Check scenario subfolder first
    const scenarioANodes = getSubfolderTable(
      this.files,
      "Scenario",
      scenarioId,
      "ANODE"
    );
    const scenarioALinks = getSubfolderTable(
      this.files,
      "Scenario",
      scenarioId,
      "ALINK"
    );

    const nodes: string[] = [];
    const links: string[] = [];

    if (scenarioANodes.length > 0) {
      for (const rec of scenarioANodes) {
        const id = getField(rec, "ID");
        if (id) nodes.push(id);
      }
    }

    if (scenarioALinks.length > 0) {
      for (const rec of scenarioALinks) {
        const id = getField(rec, "ID");
        if (id) links.push(id);
      }
    }

    // FIX #2: If no scenario subfolder data, try CBNODE/CBLINK with correct fields
    if (nodes.length === 0 && links.length === 0) {
      const cbNodes = getTable(this.files, "CBNODE");
      const cbLinks = getTable(this.files, "CBLINK");

      // Actual CBNODE fields are ID and TYPE (not SETID and STATUS)
      for (const rec of cbNodes) {
        const id = getField(rec, "ID");
        if (id) nodes.push(id);
      }
      for (const rec of cbLinks) {
        const id = getField(rec, "ID");
        if (id) links.push(id);
      }
    }

    return { nodes, links };
  }

  // ── Attribute overrides from SET files ──────────────────────────────

  private resolveAttributeOverrides(
    sets: ResolvedSets
  ): Record<string, any[]> {
    const overrides: Record<string, any[]> = {};

    // Map each SET pointer to its DBF table name
    const setTableMap: Record<string, string> = {
      jctSet: "JUNCSET",
      divSet: "DIVSET",
      ofallSet: "OFALLSET",
      storSet: "STORSET",
      subcatSet: "SUBCATSET",
      cduSet: "CONDSET",
      pumpSet: "PUMPSET",
      oriSet: "ORISET",
      weirSet: "WEIRSET",
      oletSet: "OLETSET",
      dwfSet: "DWFSET",
      rdiiSet: "RDIISET",
      iflowSet: "IFLOWSET",
      treatSet: "TREATSET",
      qualSet: "QUALSET",
      gwSet: "GWSET",
      snowSet: "SNOWSET",
      lidSet: "LIDSET",
      sublidSet: "SUBLIDSET",
      coverSet: "COVERSET",
      infilSet: "INFILSET",
      statsSet: "STATSSET",
      ctrlSet: "CTRLSET",
      soilSet: "SOILSET",
      aquifSet: "AQUIFSET",
      luSet: "LUSET",
      polluSet: "POLLUSET",
      hydghSet: "HYDGHSET",
      ruleSet: "RULESET",
      patnSet: "PATNSET",
      curveSet: "CURVESET",
      tsSet: "TSSET",
      rgageSet: "RGAGESET",
      wqSet: "WQSET",
    };

    for (const [setKey, tableName] of Object.entries(setTableMap)) {
      const setId = (sets as any)[setKey];
      if (!setId) continue;

      const records = getTable(this.files, tableName);
      if (!records.length) continue;

      // Filter records by SETID matching the scenario's set pointer value
      const matching = records.filter(
        (r: any) => getField(r, "SETID") === setId
      );
      if (matching.length > 0) {
        overrides[tableName] = matching;
      }
    }

    return overrides;
  }

  // ── Active status per element ───────────────────────────────────────

  getActiveStatus(scenarioId: string): ActiveStatusResult {
    const allNodes = getTable(this.files, "NODE");
    const allLinks = getTable(this.files, "LINK");

    // Get active element IDs for this scenario
    const facilityOverrides = this.resolveFacilityOverrides(scenarioId);

    // Build active ID sets
    const activeNodeIds = new Set(facilityOverrides.nodes);
    const activeLinkIds = new Set(facilityOverrides.links);

    // Check if we have data (empty means all active)
    const hasNodeData = activeNodeIds.size > 0;
    const hasLinkData = activeLinkIds.size > 0;

    // Get domain membership
    const dmNodes = getTable(this.files, "DMNODE");
    const dmLinks = getTable(this.files, "DMLINK");
    const dmNodeIds = new Set(dmNodes.map((r: any) => getField(r, "ID")));
    const dmLinkIds = new Set(dmLinks.map((r: any) => getField(r, "ID")));
    const hasDmNodes = dmNodes.length > 0;
    const hasDmLinks = dmLinks.length > 0;

    // Classify each node
    const nodeStatuses: ActiveElementStatus[] = [];
    for (const rec of allNodes) {
      const id = getField(rec, "ID");
      if (!id) continue;

      let status: "ACTIVE" | "INACTIVE" | "OUT_OF_DOMAIN" = "ACTIVE";
      let reason = "default_active";

      if (hasDmNodes && !dmNodeIds.has(id)) {
        status = "OUT_OF_DOMAIN";
        reason = "not_in_DMNODE";
      } else if (hasNodeData && !activeNodeIds.has(id)) {
        status = "INACTIVE";
        reason = `not_in_scenario_${scenarioId}_ANODE`;
      }

      nodeStatuses.push({
        id,
        type: getField(rec, "TYPE") || "node",
        status,
        reason,
      });
    }

    // Classify each link
    const linkStatuses: ActiveElementStatus[] = [];
    for (const rec of allLinks) {
      const id = getField(rec, "ID");
      if (!id) continue;

      let status: "ACTIVE" | "INACTIVE" | "OUT_OF_DOMAIN" = "ACTIVE";
      let reason = "default_active";

      if (hasDmLinks && !dmLinkIds.has(id)) {
        status = "OUT_OF_DOMAIN";
        reason = "not_in_DMLINK";
      } else if (hasLinkData && !activeLinkIds.has(id)) {
        status = "INACTIVE";
        reason = `not_in_scenario_${scenarioId}_ALINK`;
      }

      linkStatuses.push({
        id,
        type: getField(rec, "TYPE") || "link",
        status,
        reason,
      });
    }

    // Summary
    const activeN = nodeStatuses.filter((s) => s.status === "ACTIVE").length;
    const activeL = linkStatuses.filter((s) => s.status === "ACTIVE").length;
    const inactiveN = nodeStatuses.filter((s) => s.status === "INACTIVE").length;
    const inactiveL = linkStatuses.filter((s) => s.status === "INACTIVE").length;
    const oodN = nodeStatuses.filter((s) => s.status === "OUT_OF_DOMAIN").length;
    const oodL = linkStatuses.filter((s) => s.status === "OUT_OF_DOMAIN").length;

    return {
      scenarioId,
      summary: {
        totalNodes: allNodes.length,
        totalLinks: allLinks.length,
        activeNodes: activeN,
        activeLinks: activeL,
        inactiveNodes: inactiveN,
        inactiveLinks: inactiveL,
        outOfDomainNodes: oodN,
        outOfDomainLinks: oodL,
      },
      nodes: nodeStatuses,
      links: linkStatuses,
    };
  }

  // ── Collect all SET data ────────────────────────────────────────────

  collectAllSetData(): Record<string, Record<string, any[]>> {
    const setTables = [
      "JUNCSET", "DIVSET", "OFALLSET", "STORSET", "SUBCATSET",
      "CONDSET", "PUMPSET", "ORISET", "WEIRSET", "OLETSET",
      "DWFSET", "RDIISET", "IFLOWSET", "TREATSET", "QUALSET",
      "GWSET", "SNOWSET", "LIDSET", "SUBLIDSET",
      "COVERSET", "INFILSET", "STATSSET", "CTRLSET",
      "SOILSET", "AQUIFSET", "LUSET", "POLLUSET", "HYDGHSET",
      "RULESET", "PATNSET", "CURVESET", "TSSET", "RGAGESET", "WQSET",
    ];

    const result: Record<string, Record<string, any[]>> = {};

    for (const tableName of setTables) {
      const records = getTable(this.files, tableName);
      if (!records.length) continue;

      const grouped: Record<string, any[]> = {};
      for (const rec of records) {
        const setId = getField(rec, "SETID") || "DEFAULT";
        if (!grouped[setId]) grouped[setId] = [];
        grouped[setId].push(rec);
      }

      result[tableName] = grouped;
    }

    return result;
  }

  // ── Selection Sets ──────────────────────────────────────────────────

  getSelectionSets(): Record<string, { nodes: string[]; links: string[] }> {
    const selections: Record<string, { nodes: string[]; links: string[] }> = {};

    // Scan for Select/{name}/ANODE.dbf and ALINK.dbf
    for (const key of Object.keys(this.files)) {
      const parts = key.split("/");
      if (parts.length >= 3 && parts[0].toUpperCase() === "SELECT") {
        const selName = parts[1];
        const tableName = parts[parts.length - 1]
          .replace(/\.dbf$/i, "")
          .toUpperCase();

        if (!selections[selName]) {
          selections[selName] = { nodes: [], links: [] };
        }

        const records = this.files[key]?.records || [];
        for (const rec of records) {
          const id = getField(rec, "ID");
          if (!id) continue;
          if (tableName === "ANODE") {
            selections[selName].nodes.push(id);
          } else if (tableName === "ALINK") {
            selections[selName].links.push(id);
          }
        }
      }
    }

    return selections;
  }

  // ── Compare two scenarios within the same model ─────────────────────

  compareScenarios(
    scenarioA: string,
    scenarioB: string
  ): {
    scenarioA: string;
    scenarioB: string;
    chainA: string[];
    chainB: string[];
    setDiffs: { field: string; valueA: string; valueB: string }[];
    facilityDiffs: {
      onlyInA_nodes: string[];
      onlyInB_nodes: string[];
      onlyInA_links: string[];
      onlyInB_links: string[];
    };
    attributeDiffs: Record<string, { field: string; id: string; valueA: any; valueB: any }[]>;
  } {
    const resA = this.resolveScenario(scenarioA);
    const resB = this.resolveScenario(scenarioB);

    // Compare SET pointers
    const setDiffs: { field: string; valueA: string; valueB: string }[] = [];
    for (const key of Object.keys(resA.resolvedSets) as (keyof ResolvedSets)[]) {
      if (resA.resolvedSets[key] !== resB.resolvedSets[key]) {
        setDiffs.push({
          field: key,
          valueA: resA.resolvedSets[key],
          valueB: resB.resolvedSets[key],
        });
      }
    }

    // Compare facility (active element) differences
    const nodesA = new Set(resA.facilityOverrides.nodes);
    const nodesB = new Set(resB.facilityOverrides.nodes);
    const linksA = new Set(resA.facilityOverrides.links);
    const linksB = new Set(resB.facilityOverrides.links);

    const onlyInA_nodes = [...nodesA].filter((id) => !nodesB.has(id));
    const onlyInB_nodes = [...nodesB].filter((id) => !nodesA.has(id));
    const onlyInA_links = [...linksA].filter((id) => !linksB.has(id));
    const onlyInB_links = [...linksB].filter((id) => !linksA.has(id));

    // Compare attribute overrides
    const attributeDiffs: Record<string, { field: string; id: string; valueA: any; valueB: any }[]> = {};
    const allTableNames = new Set([
      ...Object.keys(resA.attributeOverrides),
      ...Object.keys(resB.attributeOverrides),
    ]);

    for (const tableName of allTableNames) {
      const recordsA = resA.attributeOverrides[tableName] || [];
      const recordsB = resB.attributeOverrides[tableName] || [];

      // Index by ID
      const mapA = new Map<string, any>();
      const mapB = new Map<string, any>();
      for (const r of recordsA) mapA.set(getField(r, "ID"), r);
      for (const r of recordsB) mapB.set(getField(r, "ID"), r);

      const diffs: { field: string; id: string; valueA: any; valueB: any }[] = [];
      const allIds = new Set([...mapA.keys(), ...mapB.keys()]);

      for (const id of allIds) {
        const a = mapA.get(id);
        const b = mapB.get(id);
        if (!a || !b) {
          diffs.push({
            field: "*",
            id,
            valueA: a ? "present" : "absent",
            valueB: b ? "present" : "absent",
          });
          continue;
        }
        // Compare fields
        const allFields = new Set([...Object.keys(a), ...Object.keys(b)]);
        for (const field of allFields) {
          if (field === "SETID") continue;
          const va = String(a[field] ?? "").trim();
          const vb = String(b[field] ?? "").trim();
          if (va !== vb) {
            diffs.push({ field, id, valueA: va, valueB: vb });
          }
        }
      }

      if (diffs.length > 0) {
        attributeDiffs[tableName] = diffs;
      }
    }

    return {
      scenarioA,
      scenarioB,
      chainA: resA.chain,
      chainB: resB.chain,
      setDiffs,
      facilityDiffs: {
        onlyInA_nodes,
        onlyInB_nodes,
        onlyInA_links,
        onlyInB_links,
      },
      attributeDiffs,
    };
  }
}
